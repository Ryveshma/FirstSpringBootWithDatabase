-- PostgreSQL Database Schema for Investor Module

-- Drop tables if they exist (for fresh setup)
DROP TABLE IF EXISTS transactions CASCADE;
DROP TABLE IF EXISTS holdings CASCADE;
DROP TABLE IF EXISTS wallets CASCADE;
DROP TABLE IF EXISTS portfolios CASCADE;
DROP TABLE IF EXISTS investors CASCADE;
DROP TABLE IF EXISTS stocks CASCADE;

-- Investors Table
CREATE TABLE investors (
    id BIGSERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    identity_verified BOOLEAN DEFAULT FALSE,
    verification_document VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    CONSTRAINT check_status CHECK (status IN ('ACTIVE', 'SUSPENDED', 'CLOSED'))
);

-- Portfolios Table
CREATE TABLE portfolios (
    id BIGSERIAL PRIMARY KEY,
    investor_id BIGINT NOT NULL,
    portfolio_name VARCHAR(100) NOT NULL,
    portfolio_type VARCHAR(50) DEFAULT 'STANDARD',
    total_value DECIMAL(15, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (investor_id) REFERENCES investors(id) ON DELETE CASCADE,
    CONSTRAINT check_portfolio_type CHECK (portfolio_type IN ('STANDARD', 'RETIREMENT', 'TRADING'))
);

-- Wallets Table (Cash management)
CREATE TABLE wallets (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id BIGINT NOT NULL,
    balance DECIMAL(15, 2) DEFAULT 0.00,
    currency VARCHAR(10) DEFAULT 'USD',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE
);

-- Stocks Table (Available securities)
CREATE TABLE stocks (
    id BIGSERIAL PRIMARY KEY,
    symbol VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    security_type VARCHAR(20) DEFAULT 'STOCK',
    current_price DECIMAL(10, 2) NOT NULL,
    previous_close DECIMAL(10, 2),
    market_cap DECIMAL(20, 2),
    exchange VARCHAR(50),
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_tradable BOOLEAN DEFAULT TRUE,
    CONSTRAINT check_security_type CHECK (security_type IN ('STOCK', 'ETF', 'MUTUAL_FUND'))
);

-- Holdings Table (Investor's stock positions)
CREATE TABLE holdings (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id BIGINT NOT NULL,
    stock_id BIGINT NOT NULL,
    quantity DECIMAL(15, 4) NOT NULL,
    average_price DECIMAL(10, 2) NOT NULL,
    current_value DECIMAL(15, 2),
    gain_loss DECIMAL(15, 2),
    gain_loss_percentage DECIMAL(5, 2),
    purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE,
    FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE CASCADE,
    CONSTRAINT unique_portfolio_stock UNIQUE (portfolio_id, stock_id)
);

-- Transactions Table (Buy/Sell history)
CREATE TABLE transactions (
    id BIGSERIAL PRIMARY KEY,
    portfolio_id BIGINT NOT NULL,
    stock_id BIGINT,
    transaction_type VARCHAR(20) NOT NULL,
    quantity DECIMAL(15, 4),
    price_per_unit DECIMAL(10, 2),
    total_amount DECIMAL(15, 2) NOT NULL,
    fee DECIMAL(10, 2) DEFAULT 0.00,
    status VARCHAR(20) DEFAULT 'COMPLETED',
    description TEXT,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (portfolio_id) REFERENCES portfolios(id) ON DELETE CASCADE,
    FOREIGN KEY (stock_id) REFERENCES stocks(id) ON DELETE SET NULL,
    CONSTRAINT check_transaction_type CHECK (transaction_type IN ('BUY', 'SELL', 'DEPOSIT', 'WITHDRAWAL', 'TRANSFER_IN', 'TRANSFER_OUT')),
    CONSTRAINT check_status CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'CANCELLED'))
);

-- Indexes for performance
CREATE INDEX idx_investors_email ON investors(email);
CREATE INDEX idx_portfolios_investor ON portfolios(investor_id);
CREATE INDEX idx_holdings_portfolio ON holdings(portfolio_id);
CREATE INDEX idx_holdings_stock ON holdings(stock_id);
CREATE INDEX idx_transactions_portfolio ON transactions(portfolio_id);
CREATE INDEX idx_transactions_date ON transactions(transaction_date DESC);
CREATE INDEX idx_stocks_symbol ON stocks(symbol);

-- Sample Stocks Data
INSERT INTO stocks (symbol, name, security_type, current_price, previous_close, market_cap, exchange, is_tradable) VALUES
('AAPL', 'Apple Inc.', 'STOCK', 178.50, 177.25, 2800000000000, 'NASDAQ', TRUE),
('GOOGL', 'Alphabet Inc.', 'STOCK', 140.30, 139.85, 1750000000000, 'NASDAQ', TRUE),
('MSFT', 'Microsoft Corporation', 'STOCK', 378.90, 376.40, 2820000000000, 'NASDAQ', TRUE),
('AMZN', 'Amazon.com Inc.', 'STOCK', 151.20, 150.65, 1560000000000, 'NASDAQ', TRUE),
('TSLA', 'Tesla Inc.', 'STOCK', 242.80, 245.30, 770000000000, 'NASDAQ', TRUE),
('SPY', 'SPDR S&P 500 ETF Trust', 'ETF', 456.75, 455.20, 420000000000, 'NYSE', TRUE),
('QQQ', 'Invesco QQQ Trust', 'ETF', 389.40, 388.10, 180000000000, 'NASDAQ', TRUE),
('VOO', 'Vanguard S&P 500 ETF', 'ETF', 423.50, 422.15, 350000000000, 'NYSE', TRUE),
('NVDA', 'NVIDIA Corporation', 'STOCK', 495.20, 492.80, 1220000000000, 'NASDAQ', TRUE),
('META', 'Meta Platforms Inc.', 'STOCK', 342.60, 340.25, 870000000000, 'NASDAQ', TRUE);

-- Function to update timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for auto-updating timestamps
CREATE TRIGGER update_investors_updated_at BEFORE UPDATE ON investors
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_portfolios_updated_at BEFORE UPDATE ON portfolios
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_holdings_updated_at BEFORE UPDATE ON holdings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_wallets_updated_at BEFORE UPDATE ON wallets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();