package com.investment.investor_module.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Collections;

import org.springframework.stereotype.Service;

import com.investment.investor_module.dto.request.BuyRequest;
import com.investment.investor_module.dto.request.LoginRequest;
import com.investment.investor_module.dto.request.RegisterRequest;
import com.investment.investor_module.dto.request.SellRequest;
import com.investment.investor_module.dto.request.TransferRequest;
import com.investment.investor_module.dto.response.AuthResponse;
import com.investment.investor_module.dto.response.HistoryResponse;
import com.investment.investor_module.dto.response.StockListResponse;
import com.investment.investor_module.dto.response.TransactionResponse;

@Service
public class InvestorServiceImpl implements InvestorService {

    @Override
    public AuthResponse register(RegisterRequest request) {
        AuthResponse response = new AuthResponse();
        response.setInvestorId(1L);
        response.setEmail(request.getEmail());
        response.setFirstName(request.getFirstName());
        response.setLastName(request.getLastName());
        response.setToken("dummy-registration-token");
        response.setMessage("Registered successfully (dummy)");
        return response;
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        AuthResponse response = new AuthResponse();
        response.setInvestorId(1L);
        response.setEmail(request.getEmail());
        response.setFirstName("Demo");
        response.setLastName("User");
        response.setToken("dummy-login-token");
        response.setMessage("Login successful (dummy)");
        return response;
    }

    @Override
    public String logout(String token) {
        return "Logout successful (dummy)";
    }

    @Override
    public StockListResponse getAvailableStocks() {
        StockListResponse response = new StockListResponse();
        response.setStocks(Collections.emptyList());
        return response;
    }

    @Override
    public TransactionResponse buyStock(BuyRequest request, Long investorId) {
        BigDecimal price = BigDecimal.valueOf(100);

        TransactionResponse response = new TransactionResponse();
        response.setTransactionId(1L);
        response.setTransactionType("BUY");
        response.setStockSymbol(request.getStockSymbol());
        response.setStockName("Dummy Stock");
        response.setQuantity(request.getQuantity());
        response.setPricePerUnit(price);
        response.setTotalAmount(price.multiply(request.getQuantity()));
        response.setFee(BigDecimal.ZERO);
        response.setStatus("SUCCESS");
        response.setMessage("Buy request processed (dummy)");
        response.setTransactionDate(LocalDateTime.now());
        response.setWalletBalance(BigDecimal.valueOf(10000));

        return response;
    }

    @Override
    public TransactionResponse sellStock(SellRequest request, Long investorId) {
        BigDecimal price = BigDecimal.valueOf(100);

        TransactionResponse response = new TransactionResponse();
        response.setTransactionId(2L);
        response.setTransactionType("SELL");
        response.setStockSymbol(request.getStockSymbol());
        response.setStockName("Dummy Stock");
        response.setQuantity(request.getQuantity());
        response.setPricePerUnit(price);
        response.setTotalAmount(price.multiply(request.getQuantity()));
        response.setFee(BigDecimal.ZERO);
        response.setStatus("SUCCESS");
        response.setMessage("Sell request processed (dummy)");
        response.setTransactionDate(LocalDateTime.now());
        response.setWalletBalance(BigDecimal.valueOf(10000));

        return response;
    }

    @Override
    public TransactionResponse transferFunds(TransferRequest request, Long investorId) {
        TransactionResponse response = new TransactionResponse();
        response.setTransactionId(3L);
        response.setTransactionType("TRANSFER");
        response.setTotalAmount(request.getAmount());
        response.setFee(BigDecimal.ZERO);
        response.setStatus("SUCCESS");
        response.setMessage("Funds transferred (dummy)");
        response.setTransactionDate(LocalDateTime.now());
        response.setWalletBalance(BigDecimal.valueOf(10000));

        return response;
    }

    @Override
    public HistoryResponse getPortfolioHistory(Long portfolioId, Long investorId) {
        HistoryResponse response = new HistoryResponse();
        response.setPortfolioSummary(null);
        response.setHoldings(Collections.emptyList());
        response.setTransactions(Collections.emptyList());
        return response;
    }
}
