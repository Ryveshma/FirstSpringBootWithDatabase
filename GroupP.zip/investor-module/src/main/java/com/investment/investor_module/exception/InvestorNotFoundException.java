package com.investment.investor_module.exception;

public class InvestorNotFoundException extends RuntimeException {
    public InvestorNotFoundException(String message) {
        super(message);
    }
}