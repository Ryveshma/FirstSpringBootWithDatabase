package com.investment.investor_module.service;

import com.investment.investor_module.dto.request.BuyRequest;
import com.investment.investor_module.dto.request.LoginRequest;
import com.investment.investor_module.dto.request.RegisterRequest;
import com.investment.investor_module.dto.request.SellRequest;
import com.investment.investor_module.dto.request.TransferRequest;
import com.investment.investor_module.dto.response.AuthResponse;
import com.investment.investor_module.dto.response.HistoryResponse;
import com.investment.investor_module.dto.response.StockListResponse;
import com.investment.investor_module.dto.response.TransactionResponse;

public interface InvestorService {

    /**
     * Register a new investor with identity verification
     */
    AuthResponse register(RegisterRequest request);

    /**
     * Authenticate investor and return JWT token
     */
    AuthResponse login(LoginRequest request);

    /**
     * Logout investor (invalidate token on client side)
     */
    String logout(String token);

    /**
     * Get list of available stocks and ETFs
     */
    StockListResponse getAvailableStocks();

    /**
     * Buy stocks/ETFs
     */
    TransactionResponse buyStock(BuyRequest request, Long investorId);

    /**
     * Sell investments
     */
    TransactionResponse sellStock(SellRequest request, Long investorId);

    /**
     * Transfer funds between portfolios
     */
    TransactionResponse transferFunds(TransferRequest request, Long investorId);

    /**
     * Get portfolio performance and transaction history
     */
    HistoryResponse getPortfolioHistory(Long portfolioId, Long investorId);
}