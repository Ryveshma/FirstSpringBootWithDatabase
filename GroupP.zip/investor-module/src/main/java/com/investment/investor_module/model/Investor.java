package com.investment.investor_module.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.jspecify.annotations.Nullable;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "investors")

public class Investor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(name = "first_name", nullable = false, length = 100)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 100)
    private String lastName;

    @Column(length = 20)
    private String phone;

    @Column(name = "identity_verified")
    private Boolean identityVerified = false;

    @Column(name = "verification_document")
    private String verificationDocument;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Enumerated(EnumType.STRING)
    @Column(length = 20)
    private InvestorStatus status = InvestorStatus.ACTIVE;

    @OneToMany(mappedBy = "investor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Portfolio> portfolios = new ArrayList<>();

    public enum InvestorStatus {
        ACTIVE, SUSPENDED, CLOSED
    }

	public void setEmail(String email2) {
		// TODO Auto-generated method stub

	}

	public void setPassword(@Nullable String encode) {
		// TODO Auto-generated method stub

	}

	public void setFirstName(Object firstName2) {
		// TODO Auto-generated method stub

	}

	public void setLastName(Object lastName2) {
		// TODO Auto-generated method stub

	}

	public void setPhone(Object phone2) {
		// TODO Auto-generated method stub

	}

	public Object getId() {
		// TODO Auto-generated method stub
		return null;
	}
}