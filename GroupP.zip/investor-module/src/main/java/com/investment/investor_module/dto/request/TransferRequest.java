package com.investment.investor_module.dto.request;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;

public class TransferRequest {

    @NotNull(message = "Source portfolio ID is required")
    private Long fromPortfolioId;

    @NotNull(message = "Destination portfolio ID is required")
    private Long toPortfolioId;

    @NotNull(message = "Amount is required")
    @DecimalMin(value = "0.01", message = "Amount must be greater than 0")
    private BigDecimal amount;

    private String description;

    public TransferRequest() {
    }

    public TransferRequest(Long fromPortfolioId, Long toPortfolioId,
                           BigDecimal amount, String description) {
        this.fromPortfolioId = fromPortfolioId;
        this.toPortfolioId = toPortfolioId;
        this.amount = amount;
        this.description = description;
    }

    // Getters & Setters

    public Long getFromPortfolioId() {
        return fromPortfolioId;
    }

    public void setFromPortfolioId(Long fromPortfolioId) {
        this.fromPortfolioId = fromPortfolioId;
    }

    public Long getToPortfolioId() {
        return toPortfolioId;
    }

    public void setToPortfolioId(Long toPortfolioId) {
        this.toPortfolioId = toPortfolioId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
