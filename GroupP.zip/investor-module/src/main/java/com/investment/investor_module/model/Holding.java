package com.investment.investor_module.model;

import jakarta.persistence.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

@Entity
@Table(name = "holdings", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"portfolio_id", "stock_id"})
})
public class Holding {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "portfolio_id", nullable = false)
    private Portfolio portfolio;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "stock_id", nullable = false)
    private Stock stock;

    @Column(nullable = false, precision = 15, scale = 4)
    private BigDecimal quantity;

    @Column(name = "average_price", nullable = false, precision = 10, scale = 2)
    private BigDecimal averagePrice;

    @Column(name = "current_value", precision = 15, scale = 2)
    private BigDecimal currentValue;

    @Column(name = "gain_loss", precision = 15, scale = 2)
    private BigDecimal gainLoss;

    @Column(name = "gain_loss_percentage", precision = 5, scale = 2)
    private BigDecimal gainLossPercentage;

    @CreationTimestamp
    @Column(name = "purchased_at", updatable = false)
    private LocalDateTime purchasedAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * Helper method to calculate current value, gain/loss based on current stock price
     * This method is null-safe and handles all edge cases
     */
    public void calculateCurrentValue() {
        // Check if all required fields are not null
        if (stock != null && stock.getCurrentPrice() != null && quantity != null && averagePrice != null) {
            // Calculate current value = current price * quantity
            this.currentValue = ((BigDecimal) stock.getCurrentPrice()).multiply(quantity);
            
            // Calculate total cost = average price * quantity
            BigDecimal totalCost = averagePrice.multiply(quantity);
            
            // Calculate gain/loss = current value - total cost
            this.gainLoss = currentValue.subtract(totalCost);
            
            // Calculate gain/loss percentage if total cost is positive
            if (totalCost.compareTo(BigDecimal.ZERO) > 0) {
                // Formula: (gain/loss / total cost) * 100
                this.gainLossPercentage = gainLoss
                    .divide(totalCost, 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(100));
            } else {
                this.gainLossPercentage = BigDecimal.ZERO;
            }
        } else {
            // Set default values if any required field is null
            this.currentValue = BigDecimal.ZERO;
            this.gainLoss = BigDecimal.ZERO;
            this.gainLossPercentage = BigDecimal.ZERO;
        }
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}

	public BigDecimal getQuantity() {
		return quantity;
	}

	public void setQuantity(BigDecimal quantity) {
		this.quantity = quantity;
	}

	public BigDecimal getAveragePrice() {
		return averagePrice;
	}

	public void setAveragePrice(BigDecimal averagePrice) {
		this.averagePrice = averagePrice;
	}

	public BigDecimal getGainLoss() {
		return gainLoss;
	}

	public void setGainLoss(BigDecimal gainLoss) {
		this.gainLoss = gainLoss;
	}

	public BigDecimal getGainLossPercentage() {
		return gainLossPercentage;
	}

	public void setGainLossPercentage(BigDecimal gainLossPercentage) {
		this.gainLossPercentage = gainLossPercentage;
	}

	public LocalDateTime getPurchasedAt() {
		return purchasedAt;
	}

	public void setPurchasedAt(LocalDateTime purchasedAt) {
		this.purchasedAt = purchasedAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public void setCurrentValue(BigDecimal currentValue) {
		this.currentValue = currentValue;
	}

	public Object getCurrentValue() {
		// TODO Auto-generated method stub
		return null;
	}
}