package com.investment.investor_module.dto.response;

import java.math.BigDecimal;
import java.util.List;

public class StockListResponse {

    private List<StockInfo> stocks;

    public StockListResponse() {
    }

    public StockListResponse(List<StockInfo> stocks) {
        this.stocks = stocks;
    }

    public List<StockInfo> getStocks() {
        return stocks;
    }

    public void setStocks(List<StockInfo> stocks) {
        this.stocks = stocks;
    }

    public static class StockInfo {

        private Long id;
        private String symbol;
        private String name;
        private String securityType;
        private BigDecimal currentPrice;
        private BigDecimal previousClose;
        private BigDecimal priceChange;
        private BigDecimal priceChangePercentage;
        private BigDecimal marketCap;
        private String exchange;
        private Boolean isTradable;

        public StockInfo() {
        }

        public StockInfo(Long id, String symbol, String name, String securityType,
                         BigDecimal currentPrice, BigDecimal previousClose,
                         BigDecimal priceChange, BigDecimal priceChangePercentage,
                         BigDecimal marketCap, String exchange, Boolean isTradable) {
            this.id = id;
            this.symbol = symbol;
            this.name = name;
            this.securityType = securityType;
            this.currentPrice = currentPrice;
            this.previousClose = previousClose;
            this.priceChange = priceChange;
            this.priceChangePercentage = priceChangePercentage;
            this.marketCap = marketCap;
            this.exchange = exchange;
            this.isTradable = isTradable;
        }

        // Getters & Setters

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getSecurityType() {
            return securityType;
        }

        public void setSecurityType(String securityType) {
            this.securityType = securityType;
        }

        public BigDecimal getCurrentPrice() {
            return currentPrice;
        }

        public void setCurrentPrice(BigDecimal currentPrice) {
            this.currentPrice = currentPrice;
        }

        public BigDecimal getPreviousClose() {
            return previousClose;
        }

        public void setPreviousClose(BigDecimal previousClose) {
            this.previousClose = previousClose;
        }

        public BigDecimal getPriceChange() {
            return priceChange;
        }

        public void setPriceChange(BigDecimal priceChange) {
            this.priceChange = priceChange;
        }

        public BigDecimal getPriceChangePercentage() {
            return priceChangePercentage;
        }

        public void setPriceChangePercentage(BigDecimal priceChangePercentage) {
            this.priceChangePercentage = priceChangePercentage;
        }

        public BigDecimal getMarketCap() {
            return marketCap;
        }

        public void setMarketCap(BigDecimal marketCap) {
            this.marketCap = marketCap;
        }

        public String getExchange() {
            return exchange;
        }

        public void setExchange(String exchange) {
            this.exchange = exchange;
        }

        public Boolean getIsTradable() {
            return isTradable;
        }

        public void setIsTradable(Boolean isTradable) {
            this.isTradable = isTradable;
        }
    }
}
