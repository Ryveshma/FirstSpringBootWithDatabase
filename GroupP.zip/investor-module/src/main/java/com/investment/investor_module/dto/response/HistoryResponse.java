package com.investment.investor_module.dto.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class HistoryResponse {

    private PortfolioSummary portfolioSummary;
    private List<HoldingInfo> holdings;
    private List<TransactionInfo> transactions;

    public HistoryResponse() {
    }

    public HistoryResponse(PortfolioSummary portfolioSummary,
                           List<HoldingInfo> holdings,
                           List<TransactionInfo> transactions) {
        this.portfolioSummary = portfolioSummary;
        this.holdings = holdings;
        this.transactions = transactions;
    }

    public PortfolioSummary getPortfolioSummary() {
        return portfolioSummary;
    }

    public void setPortfolioSummary(PortfolioSummary portfolioSummary) {
        this.portfolioSummary = portfolioSummary;
    }

    public List<HoldingInfo> getHoldings() {
        return holdings;
    }

    public void setHoldings(List<HoldingInfo> holdings) {
        this.holdings = holdings;
    }

    public List<TransactionInfo> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<TransactionInfo> transactions) {
        this.transactions = transactions;
    }

    // Inner classes

    public static class PortfolioSummary {

        private Long portfolioId;
        private String portfolioName;
        private BigDecimal totalValue;
        private BigDecimal cashBalance;
        private BigDecimal investedValue;
        private BigDecimal totalGainLoss;
        private BigDecimal totalGainLossPercentage;

        public PortfolioSummary() {
        }

        public PortfolioSummary(Long portfolioId, String portfolioName,
                                BigDecimal totalValue, BigDecimal cashBalance,
                                BigDecimal investedValue, BigDecimal totalGainLoss,
                                BigDecimal totalGainLossPercentage) {
            this.portfolioId = portfolioId;
            this.portfolioName = portfolioName;
            this.totalValue = totalValue;
            this.cashBalance = cashBalance;
            this.investedValue = investedValue;
            this.totalGainLoss = totalGainLoss;
            this.totalGainLossPercentage = totalGainLossPercentage;
        }

        // Getters & Setters

        public Long getPortfolioId() {
            return portfolioId;
        }

        public void setPortfolioId(Long portfolioId) {
            this.portfolioId = portfolioId;
        }

        public String getPortfolioName() {
            return portfolioName;
        }

        public void setPortfolioName(String portfolioName) {
            this.portfolioName = portfolioName;
        }

        public BigDecimal getTotalValue() {
            return totalValue;
        }

        public void setTotalValue(BigDecimal totalValue) {
            this.totalValue = totalValue;
        }

        public BigDecimal getCashBalance() {
            return cashBalance;
        }

        public void setCashBalance(BigDecimal cashBalance) {
            this.cashBalance = cashBalance;
        }

        public BigDecimal getInvestedValue() {
            return investedValue;
        }

        public void setInvestedValue(BigDecimal investedValue) {
            this.investedValue = investedValue;
        }

        public BigDecimal getTotalGainLoss() {
            return totalGainLoss;
        }

        public void setTotalGainLoss(BigDecimal totalGainLoss) {
            this.totalGainLoss = totalGainLoss;
        }

        public BigDecimal getTotalGainLossPercentage() {
            return totalGainLossPercentage;
        }

        public void setTotalGainLossPercentage(BigDecimal totalGainLossPercentage) {
            this.totalGainLossPercentage = totalGainLossPercentage;
        }
    }

    public static class HoldingInfo {

        private Long holdingId;
        private String symbol;
        private String name;
        private BigDecimal quantity;
        private BigDecimal averagePrice;
        private BigDecimal currentPrice;
        private BigDecimal currentValue;
        private BigDecimal gainLoss;
        private BigDecimal gainLossPercentage;
        private LocalDateTime purchasedAt;

        public HoldingInfo() {
        }

        public HoldingInfo(Long holdingId, String symbol, String name,
                           BigDecimal quantity, BigDecimal averagePrice,
                           BigDecimal currentPrice, BigDecimal currentValue,
                           BigDecimal gainLoss, BigDecimal gainLossPercentage,
                           LocalDateTime purchasedAt) {
            this.holdingId = holdingId;
            this.symbol = symbol;
            this.name = name;
            this.quantity = quantity;
            this.averagePrice = averagePrice;
            this.currentPrice = currentPrice;
            this.currentValue = currentValue;
            this.gainLoss = gainLoss;
            this.gainLossPercentage = gainLossPercentage;
            this.purchasedAt = purchasedAt;
        }

        // Getters & Setters

        public Long getHoldingId() {
            return holdingId;
        }

        public void setHoldingId(Long holdingId) {
            this.holdingId = holdingId;
        }

        public String getSymbol() {
            return symbol;
        }

        public void setSymbol(String symbol) {
            this.symbol = symbol;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public BigDecimal getQuantity() {
            return quantity;
        }

        public void setQuantity(BigDecimal quantity) {
            this.quantity = quantity;
        }

        public BigDecimal getAveragePrice() {
            return averagePrice;
        }

        public void setAveragePrice(BigDecimal averagePrice) {
            this.averagePrice = averagePrice;
        }

        public BigDecimal getCurrentPrice() {
            return currentPrice;
        }

        public void setCurrentPrice(BigDecimal currentPrice) {
            this.currentPrice = currentPrice;
        }

        public BigDecimal getCurrentValue() {
            return currentValue;
        }

        public void setCurrentValue(BigDecimal currentValue) {
            this.currentValue = currentValue;
        }

        public BigDecimal getGainLoss() {
            return gainLoss;
        }

        public void setGainLoss(BigDecimal gainLoss) {
            this.gainLoss = gainLoss;
        }

        public BigDecimal getGainLossPercentage() {
            return gainLossPercentage;
        }

        public void setGainLossPercentage(BigDecimal gainLossPercentage) {
            this.gainLossPercentage = gainLossPercentage;
        }

        public LocalDateTime getPurchasedAt() {
            return purchasedAt;
        }

        public void setPurchasedAt(LocalDateTime purchasedAt) {
            this.purchasedAt = purchasedAt;
        }
    }

    public static class TransactionInfo {

        private Long transactionId;
        private String transactionType;
        private String stockSymbol;
        private String stockName;
        private BigDecimal quantity;
        private BigDecimal pricePerUnit;
        private BigDecimal totalAmount;
        private BigDecimal fee;
        private String status;
        private String description;
        private LocalDateTime transactionDate;

        public TransactionInfo() {
        }

        public TransactionInfo(Long transactionId, String transactionType,
                               String stockSymbol, String stockName,
                               BigDecimal quantity, BigDecimal pricePerUnit,
                               BigDecimal totalAmount, BigDecimal fee,
                               String status, String description,
                               LocalDateTime transactionDate) {
            this.transactionId = transactionId;
            this.transactionType = transactionType;
            this.stockSymbol = stockSymbol;
            this.stockName = stockName;
            this.quantity = quantity;
            this.pricePerUnit = pricePerUnit;
            this.totalAmount = totalAmount;
            this.fee = fee;
            this.status = status;
            this.description = description;
            this.transactionDate = transactionDate;
        }

        // Getters & Setters

        public Long getTransactionId() {
            return transactionId;
        }

        public void setTransactionId(Long transactionId) {
            this.transactionId = transactionId;
        }

        public String getTransactionType() {
            return transactionType;
        }

        public void setTransactionType(String transactionType) {
            this.transactionType = transactionType;
        }

        public String getStockSymbol() {
            return stockSymbol;
        }

        public void setStockSymbol(String stockSymbol) {
            this.stockSymbol = stockSymbol;
        }

        public String getStockName() {
            return stockName;
        }

        public void setStockName(String stockName) {
            this.stockName = stockName;
        }

        public BigDecimal getQuantity() {
            return quantity;
        }

        public void setQuantity(BigDecimal quantity) {
            this.quantity = quantity;
        }

        public BigDecimal getPricePerUnit() {
            return pricePerUnit;
        }

        public void setPricePerUnit(BigDecimal pricePerUnit) {
            this.pricePerUnit = pricePerUnit;
        }

        public BigDecimal getTotalAmount() {
            return totalAmount;
        }

        public void setTotalAmount(BigDecimal totalAmount) {
            this.totalAmount = totalAmount;
        }

        public BigDecimal getFee() {
            return fee;
        }

        public void setFee(BigDecimal fee) {
            this.fee = fee;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public LocalDateTime getTransactionDate() {
            return transactionDate;
        }

        public void setTransactionDate(LocalDateTime transactionDate) {
            this.transactionDate = transactionDate;
        }
    }
}
