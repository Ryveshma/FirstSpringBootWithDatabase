package com.investment.investor_module.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.investment.investor_module.dto.request.BuyRequest;
import com.investment.investor_module.dto.request.LoginRequest;
import com.investment.investor_module.dto.request.RegisterRequest;
import com.investment.investor_module.dto.request.SellRequest;
import com.investment.investor_module.dto.request.TransferRequest;
import com.investment.investor_module.dto.response.AuthResponse;
import com.investment.investor_module.dto.response.HistoryResponse;
import com.investment.investor_module.dto.response.StockListResponse;
import com.investment.investor_module.dto.response.TransactionResponse;
import com.investment.investor_module.service.InvestorService;
import com.investment.investor_module.util.JwtUtil;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/investor")
@CrossOrigin(origins = "*")
public class InvestorController {

	private final InvestorService investorService;
    private final JwtUtil jwtUtil;

    public InvestorController(InvestorService investorService, JwtUtil jwtUtil) {
        this.investorService = investorService;
        this.jwtUtil = jwtUtil;
    }

    /**
     * Register a new investor with identity verification
     * POST /investor/register
     */
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        AuthResponse response = investorService.register(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Login - authenticate investor and return JWT token
     * POST /investor/login
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        AuthResponse response = investorService.login(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Logout - invalidate token (client-side deletion recommended)
     * POST /investor/logout
     */
    @PostMapping("/logout")
    public ResponseEntity<String> logout(@RequestHeader("Authorization") String authHeader) {
        String token = extractToken(authHeader);
        String message = investorService.logout(token);
        return ResponseEntity.ok(message);
    }

    /**
     * Get list of available stocks and ETFs
     * GET /investor/list
     */
    @GetMapping("/list")
    public ResponseEntity<StockListResponse> getAvailableStocks() {
        StockListResponse response = investorService.getAvailableStocks();
        return ResponseEntity.ok(response);
    }

    /**
     * Buy stocks or ETFs
     * POST /investor/buy
     */
    @PostMapping("/buy")
    public ResponseEntity<TransactionResponse> buyStock(
            @Valid @RequestBody BuyRequest request,
            @RequestHeader("Authorization") String authHeader) {

        Long investorId = extractInvestorIdFromToken(authHeader);
        TransactionResponse response = investorService.buyStock(request, investorId);
        return ResponseEntity.ok(response);
    }

    /**
     * Sell stocks or ETFs
     * POST /investor/sell
     */
    @PostMapping("/sell")
    public ResponseEntity<TransactionResponse> sellStock(
            @Valid @RequestBody SellRequest request,
            @RequestHeader("Authorization") String authHeader) {

        Long investorId = extractInvestorIdFromToken(authHeader);
        TransactionResponse response = investorService.sellStock(request, investorId);
        return ResponseEntity.ok(response);
    }

    /**
     * Transfer funds between portfolios
     * POST /investor/transfer
     */
    @PostMapping("/transfer")
    public ResponseEntity<TransactionResponse> transferFunds(
            @Valid @RequestBody TransferRequest request,
            @RequestHeader("Authorization") String authHeader) {

        Long investorId = extractInvestorIdFromToken(authHeader);
        TransactionResponse response = investorService.transferFunds(request, investorId);
        return ResponseEntity.ok(response);
    }

    /**
     * Get portfolio performance and transaction history
     * GET /investor/history
     */
    @GetMapping("/history")
    public ResponseEntity<HistoryResponse> getPortfolioHistory(
            @RequestParam Long portfolioId,
            @RequestHeader("Authorization") String authHeader) {

        Long investorId = extractInvestorIdFromToken(authHeader);
        HistoryResponse response = investorService.getPortfolioHistory(portfolioId, investorId);
        return ResponseEntity.ok(response);
    }

    /**
     * Helper method to extract JWT token from Authorization header
     */
    private String extractToken(String authHeader) {
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        throw new RuntimeException("Invalid authorization header");
    }

    /**
     * Helper method to extract investor ID from JWT token
     */
    private Long extractInvestorIdFromToken(String authHeader) {
        String token = extractToken(authHeader);
        return jwtUtil.extractInvestorId(token);
    }
}