package com.investment.investor_module.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.investment.investor_module.model.Holding;

@Repository
public interface HoldingRepository extends JpaRepository<Holding, Long> {
    List<Holding> findByPortfolioId(Long portfolioId);
    Optional<Holding> findByPortfolioIdAndStockId(Long portfolioId, Long stockId);

    @Query("SELECT h FROM Holding h JOIN FETCH h.stock WHERE h.portfolio.id = :portfolioId")
    List<Holding> findByPortfolioIdWithStock(@Param("portfolioId") Long portfolioId);
}