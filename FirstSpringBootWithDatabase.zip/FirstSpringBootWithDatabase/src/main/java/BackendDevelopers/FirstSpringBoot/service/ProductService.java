package BackendDevelopers.FirstSpringBoot.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import BackendDevelopers.FirstSpringBoot.dao.ProductsList;
import BackendDevelopers.FirstSpringBoot.model.Product;
/*Any class marked with @Service controls concurrent or parallel access to the DAO layer,
 * there by preventing data loss or data ambiguity or data corruption.
*/
//-> @Service automatically creates a bean for ProductService

@Service
public class ProductService {
	//Manually injecting the ProductList object into the service.
	@Autowired
	ProductsList plist;
	public ArrayList<Product> getProductsList(){
		System.out.println("Getting products list...");
		//When u call findAll() method in the repository, it executes a
		//SQL SELECT * from Products statement on the db.
		return (ArrayList<Product>)plist.findAll();
	}
	public String addProduct(Product p) {
		System.out.println("In service. Adding product...");
		Product t=plist.save(p); //Converts this to SQL INSERT statement.
		return "<b>Added or inserted the product</b>" + t;
	}
	public String deleteProduct(int productId) {
		System.out.println("In service. Deleting product...");
		//When deleteByID() is called, it will convert this into 
		//SQL DELETE from Product WHERE productId=productId
		plist.deleteById(productId);
		return "<b>Deleted product with ID </b>" + productId;
	}
	public String searchById(int productId) {
		System.out.println("In service. Searching product...");
		//If productId is 4, this is converted to SQL
		//SELECT * from Product where productId=4
		Optional<Product> opt=plist.findById(productId);
		return "Located product" + opt.get().toString();
		
	}
	public String updateProduct(int productId, String newProductName) {
		System.out.println("In service. updating product...");
		Product d=new Product(productId, newProductName);
		//When save() method is called, if any product with given productId 
		//is existing, it updates the productName with newProductName.
		//Otherwise, it inserts a new record.
		return "Updated product" + plist.save(d).toString();
	}
	
}