package BackendDevelopers.FirstSpringBoot.controllers;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import BackendDevelopers.FirstSpringBoot.model.Product;
import BackendDevelopers.FirstSpringBoot.service.ProductService;
@RestController 
//converts normal java class into a controller.
//controller has one or more API's
@RequestMapping("/shopping")
public class Shopping {
	public long visitorCount=0;

	/* Creates an object for ProductService class automatically.
	 * So, that becomes a bean, That bean is injected into the controller(Shopping).
	 * This is an example of dependency injection mechanism.
	 * Autowiring is a type of dependency injection mechanism. */
	
	@Autowired
	ProductService service;
	//this is a model.
	public Shopping() {
		
		System.err.println("Shopping Controller Created...");
	}
	//Link the API with the browser.
	//If the request type is GET and URL is http://localhost:9080/shopping/ , 
	//then call home function and return response to the client.
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String home() {
		visitorCount++;  
		//Preparing response and sends it to the client.
		String response="<html><body><h1>";
		response += "Welcome to online shopping</h1><br>";
		response += "<b>You are a visitor # </b>" + visitorCount;
		response += "</body></html>";
		return response;
	}

	/*
	 * //If the url ends with /list and the request type is GET,
	 * then getProductList() method returns the list of products to the client.
	 * Response is sent in the form of JSON by default.
	 */	
	@GetMapping(path="/list", produces=MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Product> getProductsList() {
		System.out.println("Got the request...");
		return service.getProductsList();
	}
	@GetMapping("/Search")
	public String searchProduct(@RequestParam("pId") int productId) {
		return service.searchById(productId);
		
	}  
	@DeleteMapping(path="/deleteId/{pId}")
	public String deleteProduct(@PathVariable("pId") int productId) {
		System.out.println("Got a request...");
		return service.deleteProduct(productId);

	}
	
	/* @PostMapping->
	 * used to receive post request from the client. If the URL ends with /add &
	 * request type is POST, then addProduct() method called to add a new product to
	 * the hashMap.
	 * -> When post request is issued by the client, data is sent inside the request packet.
	 * so to read the data, use @RequestBody annotation.
	 * -> All the data sent through POST request must be stored in an object only. 
	 * So we have to define a POJO class called Product.
	 * -> Every API must declare a MIME format in which it accepts the data.
	 * -> Consumes attribute makes the server to accept data in specific formats only.
	 * ->The client has to send data in the format declared by the server.
	 * ->Dependency Injection is followed. THe object p for product class is automatically 
	 * created and managed by springBoot framework. So, p is a managed object (or) also called as Java Bean.
	 */
	@PostMapping(path="/add", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Product p) {
		System.out.println("Got a POST request...");
		return service.addProduct(p);
		
	}
	@PutMapping(path="/update", consumes=MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Product p) {
		System.out.println("Got a POST request...");
		return service.updateProduct(p.getProductId(), p.getProductName());
		
	}
}