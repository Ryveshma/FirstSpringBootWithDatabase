package BackendDevelopers.FirstSpringBoot.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//Linking this POJO class to the table in the database.
@Entity
@Table(name="Product")
public class Product {
	@Id//In the database this column is the PK
	//For generating PK values automatically
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productId;
	
	//Link productName variable with productname column in the db.
	@Column(name="productName")
	private String productName;
	public Product() {
		super();
		System.out.println("New product created...");
		// TODO Auto-generated constructor stub
	}
	
	public Product(int productId, String productName) {
		super();
		this.productId = productId;
		this.productName = productName;
		System.out.println("New product created with productId & productName...");
	}

	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
		System.out.println("Stored productID");
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
		System.out.println("Stored productNAME");
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + "]" + " : " + hashCode();
	}
	
}
