
package BackendDevelopers.FirstSpringBoot;

import java.util.HashMap;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSpringBootApplication {
//entry point for spring boot application.
	public static void main(String[] args) {
		SpringApplication spr=new SpringApplication(FirstSpringBootApplication.class);
		System.out.println("Enter port no");
		Scanner sc=new Scanner(System.in);
		int port=sc.nextInt();
		HashMap portconf=new HashMap();
		portconf.put("server.port", port);
		spr.setDefaultProperties(portconf);
		spr.run(args);
		System.out.println("Started the server...");
	}

}
