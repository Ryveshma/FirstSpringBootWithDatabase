package BackendDevelopers.FirstSpringBoot.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import BackendDevelopers.FirstSpringBoot.model.Product;

@Repository
public interface ProductsList extends CrudRepository<Product, Integer>{
/* CrudRepository<Product, Integer>
 * Product is the data that will be inserted into the database
 * or retrieved from the db.
 * Integer is the datatype of the primary key.
*/
}
