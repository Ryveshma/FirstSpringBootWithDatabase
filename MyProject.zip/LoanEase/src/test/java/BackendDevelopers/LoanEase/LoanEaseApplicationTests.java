package BackendDevelopers.LoanEase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanEaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
