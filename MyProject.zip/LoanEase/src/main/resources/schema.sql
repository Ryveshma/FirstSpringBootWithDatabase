
CREATE TABLE IF NOT EXISTS app_user (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('USER','ADMIN')),
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS loan_type (
  id BIGSERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT,
  min_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  max_amount NUMERIC(12,2) NOT NULL,
  interest_rate NUMERIC(5,2) NOT NULL,
  max_tenure_months INT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS loan_application (
  id BIGSERIAL PRIMARY KEY,
  user_id BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  loan_type_id BIGINT NOT NULL REFERENCES loan_type(id),
  amount NUMERIC(12,2) NOT NULL,
  tenure_months INT NOT NULL,
  annual_income NUMERIC(12,2),
  employment_type VARCHAR(50),
  status VARCHAR(20) NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  admin_remark TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS application_document (
  id BIGSERIAL PRIMARY KEY,
  application_id BIGINT NOT NULL REFERENCES loan_application(id) ON DELETE CASCADE,
  document_type VARCHAR(50) NOT NULL,
  original_file_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(500) NOT NULL,
  uploaded_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS application_status_history (
  id BIGSERIAL PRIMARY KEY,
  application_id BIGINT NOT NULL REFERENCES loan_application(id) ON DELETE CASCADE,
  from_status VARCHAR(20) CHECK (from_status IN ('PENDING','APPROVED','REJECTED')),
  to_status VARCHAR(20) NOT NULL CHECK (to_status IN ('PENDING','APPROVED','REJECTED')),
  changed_by_user_id BIGINT REFERENCES app_user(id),
  changed_at TIMESTAMP NOT NULL DEFAULT NOW(),
  remark TEXT
);

INSERT INTO app_user (name, email, password_hash, role)
SELECT 'Admin', 'admin@loanease.local',
       '$2a$10$7QWJ8CwVclp4dYkXWg6mZeQFh2Yw1Qm3aEwGfQH7zWJg2WmYzJH3W', -- BCrypt for 'Admin@123'
       'ADMIN'
WHERE NOT EXISTS (SELECT 1 FROM app_user WHERE email='admin@loanease.local');

INSERT INTO loan_type (name, description, min_amount, max_amount, interest_rate, max_tenure_months)
SELECT 'Home Loan','Residential property',500000,10000000,8.50,360
WHERE NOT EXISTS (SELECT 1 FROM loan_type WHERE name='Home Loan');

INSERT INTO loan_type (name, description, min_amount, max_amount, interest_rate, max_tenure_months)
SELECT 'Personal Loan','Unsecured personal',10000,2000000,12.50,60
WHERE NOT EXISTS (SELECT 1 FROM loan_type WHERE name='Personal Loan');

INSERT INTO loan_type (name, description, min_amount, max_amount, interest_rate, max_tenure_months)
SELECT 'Education Loan','Tuition, study',50000,3000000,10.00,120
WHERE NOT EXISTS (SELECT 1 FROM loan_type WHERE name='Education Loan');

INSERT INTO loan_type (name, description, min_amount, max_amount, interest_rate, max_tenure_months)
SELECT 'Vehicle Loan','Cars, bikes',25000,3000000,9.75,84
WHERE NOT EXISTS (SELECT 1 FROM loan_type WHERE name='Vehicle Loan');
