package BackendDevelopers.LoanEase.model;

public enum ApplicationStatus { PENDING, APPROVED, REJECTED }
