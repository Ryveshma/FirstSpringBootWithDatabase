
/**
 * LoanEase domain models for User, LoanType, LoanApplication, etc.
 * Mirrors DAO-Service-Controller layering without JPA.
 */
package BackendDevelopers.LoanEase.model;
