package BackendDevelopers.LoanEase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanEaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanEaseApplication.class, args);
	}

}
