
package BackendDevelopers.LoanEase.controllers;

import BackendDevelopers.LoanEase.model.ApplicationStatus;
import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.model.Role;
import BackendDevelopers.LoanEase.service.AdminService;
import BackendDevelopers.LoanEase.service.TokenService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin/applications")
public class AdminController {

    private final AdminService service;
    private final TokenService tokenService;

    public AdminController(AdminService service, TokenService tokenService) {
        this.service = service;
        this.tokenService = tokenService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<LoanApplication> get(@RequestHeader("X-Auth-Token") String token,
                                               @PathVariable Long id) {
        var session = tokenService.verify(token);
        if (session == null || session.role != Role.ADMIN) return ResponseEntity.status(403).build();
        return ResponseEntity.ok(service.get(id));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<?> changeStatus(@RequestHeader("X-Auth-Token") String token,
                                          @PathVariable Long id,
                                          @RequestBody Map<String, String> body) {
        var session = tokenService.verify(token);
        if (session == null || session.role != Role.ADMIN) return ResponseEntity.status(403).build();

        ApplicationStatus to = ApplicationStatus.valueOf(body.get("status"));
        String remark = body.getOrDefault("remark", "");
        service.changeStatus(id, to, session.userId, remark);
        return ResponseEntity.ok(Map.of("status", to.name()));
    }
}
