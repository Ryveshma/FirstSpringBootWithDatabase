
package BackendDevelopers.LoanEase.controllers;

import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.service.ApplicationService;
import BackendDevelopers.LoanEase.service.TokenService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {

    private final ApplicationService service;
    private final TokenService tokenService;

    public ApplicationController(ApplicationService service, TokenService tokenService) {
        this.service = service;
        this.tokenService = tokenService;
    }

    @PostMapping
    public ResponseEntity<?> submit(@RequestHeader("X-Auth-Token") String token,
                                    @RequestBody Map<String, Object> body) {
        var session = tokenService.verify(token);
        if (session == null) return ResponseEntity.status(401).build();

        Long loanTypeId = Long.valueOf(String.valueOf(body.get("loanTypeId")));
        double amount = Double.parseDouble(String.valueOf(body.get("amount")));
        int tenureMonths = Integer.parseInt(String.valueOf(body.get("tenureMonths")));
        Double annualIncome = body.get("annualIncome") != null
                ? Double.parseDouble(String.valueOf(body.get("annualIncome"))) : null;
        String employmentType = (String) body.getOrDefault("employmentType", "OTHER");

        Long id = service.submit(session.userId, loanTypeId, amount, tenureMonths, annualIncome, employmentType);
        return ResponseEntity.ok(Map.of("applicationId", id));
    }

    @GetMapping("/mine")
    public ResponseEntity<List<LoanApplication>> mine(@RequestHeader("X-Auth-Token") String token) {
        var session = tokenService.verify(token);
        if (session == null) return ResponseEntity.status(401).build();
        return ResponseEntity.ok(service.listMine(session.userId));
    }

    @PostMapping("/{id}/documents")
    public ResponseEntity<?> upload(@RequestHeader("X-Auth-Token") String token,
                                    @PathVariable Long id,
                                    @RequestParam("documentType") String documentType,
                                    @RequestParam("file") MultipartFile file) throws Exception {
        var session = tokenService.verify(token);
        if (session == null) return ResponseEntity.status(401).build();
        Long docId = service.uploadDocument(id, documentType, file);
        return ResponseEntity.ok(Map.of("documentId", docId));
    }
}
