
package BackendDevelopers.LoanEase.controllers;

import BackendDevelopers.LoanEase.model.LoanType;
import BackendDevelopers.LoanEase.model.Role;
import BackendDevelopers.LoanEase.service.LoanTypeService;
import BackendDevelopers.LoanEase.service.TokenService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/loan-types")
public class LoanTypeController {

    private final LoanTypeService service;
    private final TokenService tokenService;

    public LoanTypeController(LoanTypeService service, TokenService tokenService) {
        this.service = service;
        this.tokenService = tokenService;
    }

    @GetMapping
    public List<LoanType> list() { return service.listActive(); }

    @PostMapping("/admin")
    public ResponseEntity<?> add(@RequestHeader("X-Auth-Token") String token,
                                 @RequestBody LoanType lt) {
        var session = tokenService.verify(token);
        if (session == null || session.role != Role.ADMIN) return ResponseEntity.status(403).build();
        Long id = service.add(lt);
        return ResponseEntity.ok(Map.of("id", id));
    }

    @DeleteMapping("/admin/{id}")
    public ResponseEntity<?> delete(@RequestHeader("X-Auth-Token") String token,
                                    @PathVariable Long id) {
        var session = tokenService.verify(token);
        if (session == null || session.role != Role.ADMIN) return ResponseEntity.status(403).build();
        service.remove(id);
        return ResponseEntity.noContent().build();
    }
}
