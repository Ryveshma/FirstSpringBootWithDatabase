
package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.LoanTypeDao;
import BackendDevelopers.LoanEase.model.LoanType;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoanTypeService {
    private final LoanTypeDao dao;
    public LoanTypeService(LoanTypeDao dao) { this.dao = dao; }

    public List<LoanType> listActive() { return dao.findAllActive(); }
    public Long add(LoanType lt) { return dao.insert(lt); }
    public int remove(Long id) { return dao.delete(id); }
}
