
package BackendDevelopers.LoanEase.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Service
public class StorageService {

    @Value("${loanease.upload.root-dir:/var/loanease/uploads}")
    private String rootDir;

    public Path store(Long applicationId, MultipartFile file) throws Exception {
        Path appDir = Paths.get(rootDir, String.valueOf(applicationId));
        Files.createDirectories(appDir);
        Path target = appDir.resolve(file.getOriginalFilename());
        Files.copy(file.getInputStream(), target);
        return target;
    }
}
