
package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.ApplicationDocumentDao;
import BackendDevelopers.LoanEase.dao.LoanApplicationDao;
import BackendDevelopers.LoanEase.dao.LoanTypeDao;
import BackendDevelopers.LoanEase.model.ApplicationDocument;
import BackendDevelopers.LoanEase.model.ApplicationStatus;
import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.model.LoanType;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;
import java.util.List;

@Service
public class ApplicationService {

    private final LoanApplicationDao applicationDao;
    private final LoanTypeDao loanTypeDao;
    private final ApplicationDocumentDao documentDao;
    private final StorageService storageService;

    public ApplicationService(LoanApplicationDao applicationDao, LoanTypeDao loanTypeDao,
                              ApplicationDocumentDao documentDao, StorageService storageService) {
        this.applicationDao = applicationDao;
        this.loanTypeDao = loanTypeDao;
        this.documentDao = documentDao;
        this.storageService = storageService;
    }

    public Long submit(Long userId, Long loanTypeId, double amount, int tenureMonths,
                       Double annualIncome, String employmentType) {
        LoanType lt = loanTypeDao.findById(loanTypeId)
                .orElseThrow(() -> new IllegalArgumentException("Invalid loan type"));

        if (amount < lt.getMinAmount() || amount > lt.getMaxAmount())
            throw new IllegalArgumentException("Amount must be within loan type limits");
        if (tenureMonths < 1 || tenureMonths > lt.getMaxTenureMonths())
            throw new IllegalArgumentException("Invalid tenure for loan type");

        LoanApplication a = new LoanApplication();
        a.setUserId(userId);
        a.setLoanTypeId(loanTypeId);
        a.setAmount(amount);
        a.setTenureMonths(tenureMonths);
        a.setAnnualIncome(annualIncome);
        a.setEmploymentType(employmentType);
        a.setStatus(ApplicationStatus.PENDING);

        return applicationDao.insert(a);
    }

    public List<LoanApplication> listMine(Long userId) { return applicationDao.findByUser(userId); }

    public Long uploadDocument(Long applicationId, String documentType, MultipartFile file) throws Exception {
        Path stored = storageService.store(applicationId, file);
        ApplicationDocument d = new ApplicationDocument();
        d.setApplicationId(applicationId);
        d.setDocumentType(documentType);
        d.setOriginalFileName(file.getOriginalFilename());
        d.setStoredPath(stored.toAbsolutePath().toString());
        return documentDao.insert(d);
    }
}
