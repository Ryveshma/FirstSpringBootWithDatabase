
package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.LoanApplicationDao;
import BackendDevelopers.LoanEase.dao.StatusHistoryDao;
import BackendDevelopers.LoanEase.model.ApplicationStatus;
import BackendDevelopers.LoanEase.model.LoanApplication;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    private final LoanApplicationDao applicationDao;
    private final StatusHistoryDao historyDao;

    public AdminService(LoanApplicationDao applicationDao, StatusHistoryDao historyDao) {
        this.applicationDao = applicationDao;
        this.historyDao = historyDao;
    }

    public LoanApplication get(Long id) {
        return applicationDao.findById(id).orElseThrow(() -> new IllegalArgumentException("Application not found"));
    }

    public void changeStatus(Long id, ApplicationStatus toStatus, Long adminUserId, String remark) {
        LoanApplication current = get(id);
        ApplicationStatus from = current.getStatus();
        applicationDao.updateStatus(id, toStatus, remark);
        historyDao.append(id, from, toStatus, adminUserId, remark);
    }
}
