
package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.UserDao;
import BackendDevelopers.LoanEase.model.Role;
import BackendDevelopers.LoanEase.model.User;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final UserDao userDao;
    private final TokenService tokenService;

    public AuthService(UserDao userDao, TokenService tokenService) {
        this.userDao = userDao;
        this.tokenService = tokenService;
    }

    public Long register(String name, String email, String rawPassword) {
        Optional<User> exists = userDao.findByEmail(email);
        if (exists.isPresent()) throw new IllegalArgumentException("Email already registered");

        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setRole(Role.USER);
        u.setPasswordHash(BCrypt.hashpw(rawPassword, BCrypt.gensalt(10)));
        return userDao.insert(u);
    }

    public String login(String email, String rawPassword) {
        User u = userDao.findByEmail(email).orElseThrow(() -> new IllegalArgumentException("Invalid credentials"));
        if (!BCrypt.checkpw(rawPassword, u.getPasswordHash())) throw new IllegalArgumentException("Invalid credentials");
        return tokenService.issueToken(u.getId(), u.getRole(), u.getEmail());
    }

    public void logout(String token) { tokenService.revoke(token); }
}
