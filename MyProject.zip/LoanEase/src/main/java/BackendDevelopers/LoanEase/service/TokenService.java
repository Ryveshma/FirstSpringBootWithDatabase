
package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.model.Role;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class TokenService {

    public static class SessionUser {
        public Long userId;
        public Role role;
        public String email;
        public SessionUser(Long userId, Role role, String email) {
            this.userId = userId; this.role = role; this.email = email;
        }
    }

    private final Map<String, SessionUser> tokens = new ConcurrentHashMap<>();

    public String issueToken(Long userId, Role role, String email) {
        String token = UUID.randomUUID().toString();
        tokens.put(token, new SessionUser(userId, role, email));
        return token;
    }

    public SessionUser verify(String token) { return token != null ? tokens.get(token) : null; }

    public void revoke(String token) { if (token != null) tokens.remove(token); }
}
