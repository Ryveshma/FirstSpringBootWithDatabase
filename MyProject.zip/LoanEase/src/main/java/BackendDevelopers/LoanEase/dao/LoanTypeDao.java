
package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.LoanType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class LoanTypeDao {

    private final JdbcTemplate jdbc;

    public LoanTypeDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private final RowMapper<LoanType> mapper = new RowMapper<>() {
        @Override
        public LoanType mapRow(ResultSet rs, int rowNum) throws SQLException {
            LoanType lt = new LoanType();
            lt.setId(rs.getLong("id"));
            lt.setName(rs.getString("name"));
            lt.setDescription(rs.getString("description"));
            lt.setMinAmount(rs.getDouble("min_amount"));
            lt.setMaxAmount(rs.getDouble("max_amount"));
            lt.setInterestRate(rs.getDouble("interest_rate"));
            lt.setMaxTenureMonths(rs.getInt("max_tenure_months"));
            lt.setActive(rs.getBoolean("is_active"));
            return lt;
        }
    };

    public List<LoanType> findAllActive() {
        return jdbc.query("SELECT * FROM loan_type WHERE is_active = TRUE ORDER BY name", mapper);
    }

    public Optional<LoanType> findById(Long id) {
        var list = jdbc.query("SELECT * FROM loan_type WHERE id = ?", mapper, id);
        return list.stream().findFirst();
    }

    public Long insert(LoanType lt) {
        String sql = """
            INSERT INTO loan_type(name, description, min_amount, max_amount, interest_rate, max_tenure_months, is_active)
            VALUES (?, ?, ?, ?, ?, ?, TRUE)
        """;
        jdbc.update(sql, lt.getName(), lt.getDescription(), lt.getMinAmount(), lt.getMaxAmount(),
                lt.getInterestRate(), lt.getMaxTenureMonths());
        return jdbc.queryForObject("SELECT id FROM loan_type WHERE name = ?", Long.class, lt.getName());
    }

    public int delete(Long id) { return jdbc.update("DELETE FROM loan_type WHERE id = ?", id); }
}
