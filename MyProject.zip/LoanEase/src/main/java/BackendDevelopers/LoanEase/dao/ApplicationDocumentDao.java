
package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.ApplicationDocument;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class ApplicationDocumentDao {

    private final JdbcTemplate jdbc;

    public ApplicationDocumentDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private final RowMapper<ApplicationDocument> mapper = new RowMapper<>() {
        @Override
        public ApplicationDocument mapRow(ResultSet rs, int rowNum) throws SQLException {
            ApplicationDocument d = new ApplicationDocument();
            d.setId(rs.getLong("id"));
            d.setApplicationId(rs.getLong("application_id"));
            d.setDocumentType(rs.getString("document_type"));
            d.setOriginalFileName(rs.getString("original_file_name"));
            d.setStoredPath(rs.getString("stored_path"));
            d.setUploadedAt(rs.getTimestamp("uploaded_at").toInstant());
            return d;
        }
    };

    public Long insert(ApplicationDocument d) {
        String sql = """
            INSERT INTO application_document(application_id, document_type, original_file_name, stored_path)
            VALUES (?, ?, ?, ?)
        """;
        jdbc.update(sql, d.getApplicationId(), d.getDocumentType(), d.getOriginalFileName(), d.getStoredPath());
        return jdbc.queryForObject(
                "SELECT id FROM application_document WHERE application_id=? ORDER BY id DESC LIMIT 1",
                Long.class, d.getApplicationId());
    }

    public List<ApplicationDocument> listByApplication(Long appId) {
        return jdbc.query("SELECT * FROM application_document WHERE application_id=?", mapper, appId);
    }
}
