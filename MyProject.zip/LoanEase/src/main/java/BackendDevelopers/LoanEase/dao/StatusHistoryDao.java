
package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.ApplicationStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class StatusHistoryDao {

    private final JdbcTemplate jdbc;

    public StatusHistoryDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public void append(Long appId, ApplicationStatus from, ApplicationStatus to, Long adminUserId, String remark) {
        String sql = """
            INSERT INTO application_status_history(application_id, from_status, to_status, changed_by_user_id, remark)
            VALUES (?, ?, ?, ?, ?)
        """;
        jdbc.update(sql, appId, from != null ? from.name() : null, to.name(), adminUserId, remark);
    }
}
