
package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.Role;
import BackendDevelopers.LoanEase.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.Optional;

@Repository
public class UserDao {

    private final JdbcTemplate jdbc;

    public UserDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private final RowMapper<User> mapper = new RowMapper<>() {
        @Override
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User u = new User();
            u.setId(rs.getLong("id"));
            u.setName(rs.getString("name"));
            u.setEmail(rs.getString("email"));
            u.setPasswordHash(rs.getString("password_hash"));
            u.setRole(Role.valueOf(rs.getString("role")));
            u.setCreatedAt(rs.getTimestamp("created_at").toInstant());
            return u;
        }
    };

    public Optional<User> findByEmail(String email) {
        var list = jdbc.query("SELECT * FROM app_user WHERE email = ?", mapper, email);
        return list.stream().findFirst();
    }

    public Optional<User> findById(Long id) {
        var list = jdbc.query("SELECT * FROM app_user WHERE id = ?", mapper, id);
        return list.stream().findFirst();
    }

    public Long insert(User u) {
        String sql = """
            INSERT INTO app_user(name, email, password_hash, role, created_at)
            VALUES (?, ?, ?, ?, ?)
        """;
        Instant now = Instant.now();
        jdbc.update(sql, u.getName(), u.getEmail(), u.getPasswordHash(), u.getRole().name(), now);
        return jdbc.queryForObject("SELECT id FROM app_user WHERE email = ?", Long.class, u.getEmail());
    }
}
