
package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.ApplicationStatus;
import BackendDevelopers.LoanEase.model.LoanApplication;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class LoanApplicationDao {

    private final JdbcTemplate jdbc;

    public LoanApplicationDao(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private final RowMapper<LoanApplication> mapper = new RowMapper<>() {
        @Override
        public LoanApplication mapRow(ResultSet rs, int rowNum) throws SQLException {
            LoanApplication a = new LoanApplication();
            a.setId(rs.getLong("id"));
            a.setUserId(rs.getLong("user_id"));
            a.setLoanTypeId(rs.getLong("loan_type_id"));
            a.setAmount(rs.getDouble("amount"));
            a.setTenureMonths(rs.getInt("tenure_months"));
            var inc = rs.getBigDecimal("annual_income");
            a.setAnnualIncome(inc != null ? inc.doubleValue() : null);
            a.setEmploymentType(rs.getString("employment_type"));
            a.setStatus(ApplicationStatus.valueOf(rs.getString("status")));
            a.setAdminRemark(rs.getString("admin_remark"));
            a.setCreatedAt(rs.getTimestamp("created_at").toInstant());
            a.setUpdatedAt(rs.getTimestamp("updated_at").toInstant());
            return a;
        }
    };

    public Long insert(LoanApplication a) {
        String sql = """
            INSERT INTO loan_application(user_id, loan_type_id, amount, tenure_months, annual_income, employment_type, status, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, 'PENDING', NOW(), NOW())
        """;
        jdbc.update(sql, a.getUserId(), a.getLoanTypeId(), a.getAmount(), a.getTenureMonths(),
                a.getAnnualIncome(), a.getEmploymentType());
        return jdbc.queryForObject(
                "SELECT id FROM loan_application WHERE user_id=? ORDER BY id DESC LIMIT 1",
                Long.class, a.getUserId());
    }

    public List<LoanApplication> findByUser(Long userId) {
        return jdbc.query("SELECT * FROM loan_application WHERE user_id = ? ORDER BY created_at DESC", mapper, userId);
    }

    public Optional<LoanApplication> findById(Long id) {
        var list = jdbc.query("SELECT * FROM loan_application WHERE id = ?", mapper, id);
        return list.stream().findFirst();
    }

    public int updateStatus(Long id, ApplicationStatus toStatus, String adminRemark) {
        String sql = """
            UPDATE loan_application SET status=?, admin_remark=?, updated_at=NOW() WHERE id=?
        """;
        return jdbc.update(sql, toStatus.name(), adminRemark, id);
    }
}
