package com.investment.investor_module.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.investment.investor_module.model.Transaction;

import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByPortfolioIdOrderByTransactionDateDesc(Long portfolioId);
    
    @Query("SELECT t FROM Transaction t JOIN FETCH t.stock WHERE t.portfolio.id = :portfolioId ORDER BY t.transactionDate DESC")
    List<Transaction> findByPortfolioIdWithStockOrderByTransactionDateDesc(@Param("portfolioId") Long portfolioId);
    
    List<Transaction> findByPortfolioInvestorIdOrderByTransactionDateDesc(Long investorId);
}