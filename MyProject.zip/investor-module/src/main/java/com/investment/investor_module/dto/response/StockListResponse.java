package com.investment.investor_module.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StockListResponse {
    private List<StockInfo> stocks;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StockInfo {
        private Long id;
        private String symbol;
        private String name;
        private String securityType;
        private BigDecimal currentPrice;
        private BigDecimal previousClose;
        private BigDecimal priceChange;
        private BigDecimal priceChangePercentage;
        private BigDecimal marketCap;
        private String exchange;
        private Boolean isTradable;
    }
}