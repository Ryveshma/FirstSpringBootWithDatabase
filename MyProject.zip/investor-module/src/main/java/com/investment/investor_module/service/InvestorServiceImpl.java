package com.investment.investor_module.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.investment.investor_module.dto.request.*;
import com.investment.investor_module.dto.response.*;
import com.investment.investor_module.exception.*;
import com.investment.investor_module.model.*;
import com.investment.investor_module.repository.*;
import com.investment.investor_module.service.InvestorService;
import com.investment.investor_module.util.JwtUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InvestorServiceImpl implements InvestorService {

    private final InvestorRepository investorRepository;
    private final PortfolioRepository portfolioRepository;
    private final StockRepository stockRepository;
    private final HoldingRepository holdingRepository;
    private final TransactionRepository transactionRepository;
    private final WalletRepository walletRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        // Check if email already exists
        if (investorRepository.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        // Create investor
        Investor investor = new Investor();
        investor.setEmail(request.getEmail());
        investor.setPassword(passwordEncoder.encode(request.getPassword()));
        investor.setFirstName(request.getFirstName());
        investor.setLastName(request.getLastName());
        investor.setPhone(request.getPhone());
        investor.setVerificationDocument(request.getVerificationDocument());
        investor.setIdentityVerified(request.getVerificationDocument() != null);
        investor.setStatus(Investor.InvestorStatus.ACTIVE);

        investor = investorRepository.save(investor);

        // Create default portfolio
        Portfolio portfolio = new Portfolio();
        portfolio.setInvestor(investor);
        portfolio.setPortfolioName(request.getInitialPortfolioName());
        portfolio.setPortfolioType(Portfolio.PortfolioType.STANDARD);
        portfolio.setTotalValue(BigDecimal.ZERO);
        portfolio = portfolioRepository.save(portfolio);

        // Create wallet with initial balance
        Wallet wallet = new Wallet();
        wallet.setPortfolio(portfolio);
        wallet.setBalance(BigDecimal.valueOf(10000)); // Initial demo balance
        wallet.setCurrency("USD");
        walletRepository.save(wallet);

        // Generate JWT token
        String token = jwtUtil.generateToken(investor.getEmail(), investor.getId());

        return AuthResponse.builder()
                .investorId(investor.getId())
                .email(investor.getEmail())
                .firstName(investor.getFirstName())
                .lastName(investor.getLastName())
                .token(token)
                .message("Registration successful")
                .build();
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        Investor investor = investorRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new InvalidCredentialsException("Invalid email or password"));

        if (!passwordEncoder.matches(request.getPassword(), investor.getPassword())) {
            throw new InvalidCredentialsException("Invalid email or password");
        }

        if (investor.getStatus() != Investor.InvestorStatus.ACTIVE) {
            throw new InvalidCredentialsException("Account is not active");
        }

        String token = jwtUtil.generateToken(investor.getEmail(), investor.getId());

        return AuthResponse.builder()
                .investorId(investor.getId())
                .email(investor.getEmail())
                .firstName(investor.getFirstName())
                .lastName(investor.getLastName())
                .token(token)
                .message("Login successful")
                .build();
    }

    @Override
    public String logout(String token) {
        // In a real application, you would invalidate the token
        // by adding it to a blacklist in Redis or database
        return "Logout successful";
    }

    @Override
    public StockListResponse getAvailableStocks() {
        List<Stock> stocks = stockRepository.findAll();

        List<StockListResponse.StockInfo> stockInfos = stocks.stream()
                .map(stock -> {
                    BigDecimal priceChange = stock.getPreviousClose() != null
                            ? stock.getCurrentPrice().subtract(stock.getPreviousClose())
                            : BigDecimal.ZERO;

                    BigDecimal priceChangePercentage = stock.getPreviousClose() != null
                            && stock.getPreviousClose().compareTo(BigDecimal.ZERO) > 0
                            ? priceChange.divide(stock.getPreviousClose(), 4, RoundingMode.HALF_UP)
                            .multiply(BigDecimal.valueOf(100))
                            : BigDecimal.ZERO;

                    return StockListResponse.StockInfo.builder()
                            .id(stock.getId())
                            .symbol(stock.getSymbol())
                            .name(stock.getName())
                            .securityType(stock.getSecurityType().toString())
                            .currentPrice(stock.getCurrentPrice())
                            .previousClose(stock.getPreviousClose())
                            .priceChange(priceChange)
                            .priceChangePercentage(priceChangePercentage)
                            .marketCap(stock.getMarketCap())
                            .exchange(stock.getExchange())
                            .isTradable(stock.getIsTradable())
                            .build();
                })
                .collect(Collectors.toList());

        return StockListResponse.builder()
                .stocks(stockInfos)
                .build();
    }

    @Override
    @Transactional
    public TransactionResponse buyStock(BuyRequest request, Long investorId) {
        // Validate portfolio belongs to investor
        Portfolio portfolio = portfolioRepository.findByIdAndInvestorId(request.getPortfolioId(), investorId)
                .orElseThrow(() -> new PortfolioNotFoundException("Portfolio not found or does not belong to investor"));

        // Get stock
        Stock stock = stockRepository.findBySymbol(request.getStockSymbol())
                .orElseThrow(() -> new StockNotFoundException("Stock not found: " + request.getStockSymbol()));

        if (!stock.getIsTradable()) {
            throw new RuntimeException("Stock is not tradable");
        }

        // Calculate total cost
        BigDecimal totalCost = stock.getCurrentPrice().multiply(request.getQuantity());
        BigDecimal fee = totalCost.multiply(BigDecimal.valueOf(0.001)); // 0.1% trading fee
        BigDecimal totalAmount = totalCost.add(fee);

        // Check wallet balance
        Wallet wallet = walletRepository.findByPortfolioId(portfolio.getId())
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        if (wallet.getBalance().compareTo(totalAmount) < 0) {
            throw new InsufficientFundsException("Insufficient funds. Required: " + totalAmount + ", Available: " + wallet.getBalance());
        }

        // Deduct from wallet
        wallet.setBalance(wallet.getBalance().subtract(totalAmount));
        walletRepository.save(wallet);

        // Update or create holding
        Holding holding = holdingRepository.findByPortfolioIdAndStockId(portfolio.getId(), stock.getId())
                .orElse(new Holding());

        if (holding.getId() == null) {
            // New holding
            holding.setPortfolio(portfolio);
            holding.setStock(stock);
            holding.setQuantity(request.getQuantity());
            holding.setAveragePrice(stock.getCurrentPrice());
        } else {
            // Update existing holding - calculate new average price
            BigDecimal currentTotalCost = holding.getAveragePrice().multiply(holding.getQuantity());
            BigDecimal newTotalCost = currentTotalCost.add(totalCost);
            BigDecimal newTotalQuantity = holding.getQuantity().add(request.getQuantity());
            holding.setQuantity(newTotalQuantity);
            holding.setAveragePrice(newTotalCost.divide(newTotalQuantity, 2, RoundingMode.HALF_UP));
        }

        holding.calculateCurrentValue();
        holdingRepository.save(holding);

        // Create transaction record
        Transaction transaction = new Transaction();
        transaction.setPortfolio(portfolio);
        transaction.setStock(stock);
        transaction.setTransactionType(Transaction.TransactionType.BUY);
        transaction.setQuantity(request.getQuantity());
        transaction.setPricePerUnit(stock.getCurrentPrice());
        transaction.setTotalAmount(totalAmount);
        transaction.setFee(fee);
        transaction.setStatus(Transaction.TransactionStatus.COMPLETED);
        transaction.setDescription("Bought " + request.getQuantity() + " shares of " + stock.getSymbol());
        transaction = transactionRepository.save(transaction);

        // Update portfolio total value
        updatePortfolioValue(portfolio);

        return TransactionResponse.builder()
                .transactionId(transaction.getId())
                .transactionType(transaction.getTransactionType().toString())
                .stockSymbol(stock.getSymbol())
                .stockName(stock.getName())
                .quantity(request.getQuantity())
                .pricePerUnit(stock.getCurrentPrice())
                .totalAmount(totalAmount)
                .fee(fee)
                .status(transaction.getStatus().toString())
                .message("Successfully bought " + request.getQuantity() + " shares of " + stock.getSymbol())
                .transactionDate(transaction.getTransactionDate())
                .walletBalance(wallet.getBalance())
                .build();
    }

    @Override
    @Transactional
    public TransactionResponse sellStock(SellRequest request, Long investorId) {
        // Validate portfolio belongs to investor
        Portfolio portfolio = portfolioRepository.findByIdAndInvestorId(request.getPortfolioId(), investorId)
                .orElseThrow(() -> new PortfolioNotFoundException("Portfolio not found or does not belong to investor"));

        // Get stock
        Stock stock = stockRepository.findBySymbol(request.getStockSymbol())
                .orElseThrow(() -> new StockNotFoundException("Stock not found: " + request.getStockSymbol()));

        // Get holding
        Holding holding = holdingRepository.findByPortfolioIdAndStockId(portfolio.getId(), stock.getId())
                .orElseThrow(() -> new InsufficientHoldingException("No holding found for " + request.getStockSymbol()));

        if (holding.getQuantity().compareTo(request.getQuantity()) < 0) {
            throw new InsufficientHoldingException("Insufficient shares. Requested: " + request.getQuantity() + ", Available: " + holding.getQuantity());
        }

        // Calculate sale amount
        BigDecimal saleAmount = stock.getCurrentPrice().multiply(request.getQuantity());
        BigDecimal fee = saleAmount.multiply(BigDecimal.valueOf(0.001)); // 0.1% trading fee
        BigDecimal netAmount = saleAmount.subtract(fee);

        // Update holding
        BigDecimal newQuantity = holding.getQuantity().subtract(request.getQuantity());
        if (newQuantity.compareTo(BigDecimal.ZERO) == 0) {
            holdingRepository.delete(holding);
        } else {
            holding.setQuantity(newQuantity);
            holding.calculateCurrentValue();
            holdingRepository.save(holding);
        }

        // Add to wallet
        Wallet wallet = walletRepository.findByPortfolioId(portfolio.getId())
                .orElseThrow(() -> new RuntimeException("Wallet not found"));
        wallet.setBalance(wallet.getBalance().add(netAmount));
        walletRepository.save(wallet);

        // Create transaction record
        Transaction transaction = new Transaction();
        transaction.setPortfolio(portfolio);
        transaction.setStock(stock);
        transaction.setTransactionType(Transaction.TransactionType.SELL);
        transaction.setQuantity(request.getQuantity());
        transaction.setPricePerUnit(stock.getCurrentPrice());
        transaction.setTotalAmount(netAmount);
        transaction.setFee(fee);
        transaction.setStatus(Transaction.TransactionStatus.COMPLETED);
        transaction.setDescription("Sold " + request.getQuantity() + " shares of " + stock.getSymbol());
        transaction = transactionRepository.save(transaction);

        // Update portfolio total value
        updatePortfolioValue(portfolio);

        return TransactionResponse.builder()
                .transactionId(transaction.getId())
                .transactionType(transaction.getTransactionType().toString())
                .stockSymbol(stock.getSymbol())
                .stockName(stock.getName())
                .quantity(request.getQuantity())
                .pricePerUnit(stock.getCurrentPrice())
                .totalAmount(netAmount)
                .fee(fee)
                .status(transaction.getStatus().toString())
                .message("Successfully sold " + request.getQuantity() + " shares of " + stock.getSymbol())
                .transactionDate(transaction.getTransactionDate())
                .walletBalance(wallet.getBalance())
                .build();
    }

    @Override
    @Transactional
    public TransactionResponse transferFunds(TransferRequest request, Long investorId) {
        // Validate source portfolio
        Portfolio fromPortfolio = portfolioRepository.findByIdAndInvestorId(request.getFromPortfolioId(), investorId)
                .orElseThrow(() -> new PortfolioNotFoundException("Source portfolio not found"));

        // Validate destination portfolio
        Portfolio toPortfolio = portfolioRepository.findByIdAndInvestorId(request.getToPortfolioId(), investorId)
                .orElseThrow(() -> new PortfolioNotFoundException("Destination portfolio not found"));

        // Get wallets
        Wallet fromWallet = walletRepository.findByPortfolioId(fromPortfolio.getId())
                .orElseThrow(() -> new RuntimeException("Source wallet not found"));

        Wallet toWallet = walletRepository.findByPortfolioId(toPortfolio.getId())
                .orElseThrow(() -> new RuntimeException("Destination wallet not found"));

        // Check balance
        if (fromWallet.getBalance().compareTo(request.getAmount()) < 0) {
            throw new InsufficientFundsException("Insufficient funds in source portfolio");
        }

        // Transfer funds
        fromWallet.setBalance(fromWallet.getBalance().subtract(request.getAmount()));
        toWallet.setBalance(toWallet.getBalance().add(request.getAmount()));

        walletRepository.save(fromWallet);
        walletRepository.save(toWallet);

        // Create transaction records
        Transaction outTransaction = new Transaction();
        outTransaction.setPortfolio(fromPortfolio);
        outTransaction.setTransactionType(Transaction.TransactionType.TRANSFER_OUT);
        outTransaction.setTotalAmount(request.getAmount());
        outTransaction.setStatus(Transaction.TransactionStatus.COMPLETED);
        outTransaction.setDescription(request.getDescription() != null ? request.getDescription() : "Transfer to " + toPortfolio.getPortfolioName());
        transactionRepository.save(outTransaction);

        Transaction inTransaction = new Transaction();
        inTransaction.setPortfolio(toPortfolio);
        inTransaction.setTransactionType(Transaction.TransactionType.TRANSFER_IN);
        inTransaction.setTotalAmount(request.getAmount());
        inTransaction.setStatus(Transaction.TransactionStatus.COMPLETED);
        inTransaction.setDescription(request.getDescription() != null ? request.getDescription() : "Transfer from " + fromPortfolio.getPortfolioName());
        transactionRepository.save(inTransaction);

        return TransactionResponse.builder()
                .transactionId(outTransaction.getId())
                .transactionType("TRANSFER")
                .totalAmount(request.getAmount())
                .status("COMPLETED")
                .message("Successfully transferred " + request.getAmount() + " from " + fromPortfolio.getPortfolioName() + " to " + toPortfolio.getPortfolioName())
                .transactionDate(outTransaction.getTransactionDate())
                .walletBalance(fromWallet.getBalance())
                .build();
    }

    @Override
    public HistoryResponse getPortfolioHistory(Long portfolioId, Long investorId) {
        // Validate portfolio
        Portfolio portfolio = portfolioRepository.findByIdAndInvestorId(portfolioId, investorId)
                .orElseThrow(() -> new PortfolioNotFoundException("Portfolio not found"));

        // Get wallet
        Wallet wallet = walletRepository.findByPortfolioId(portfolioId)
                .orElseThrow(() -> new RuntimeException("Wallet not found"));

        // Get holdings
        List<Holding> holdings = holdingRepository.findByPortfolioIdWithStock(portfolioId);
        
        // Calculate totals
        BigDecimal totalInvestedValue = BigDecimal.ZERO;
        BigDecimal totalCurrentValue = BigDecimal.ZERO;
        BigDecimal totalGainLoss = BigDecimal.ZERO;

        for (Holding holding : holdings) {
            holding.calculateCurrentValue();
            totalInvestedValue = totalInvestedValue.add(holding.getAveragePrice().multiply(holding.getQuantity()));
            totalCurrentValue = totalCurrentValue.add(holding.getCurrentValue());
            totalGainLoss = totalGainLoss.add(holding.getGainLoss());
        }

        BigDecimal totalGainLossPercentage = totalInvestedValue.compareTo(BigDecimal.ZERO) > 0
                ? totalGainLoss.divide(totalInvestedValue, 4, RoundingMode.HALF_UP).multiply(BigDecimal.valueOf(100))
                : BigDecimal.ZERO;

        BigDecimal totalPortfolioValue = totalCurrentValue.add(wallet.getBalance());

        // Build portfolio summary
        HistoryResponse.PortfolioSummary summary = HistoryResponse.PortfolioSummary.builder()
                .portfolioId(portfolio.getId())
                .portfolioName(portfolio.getPortfolioName())
                .totalValue(totalPortfolioValue)
                .cashBalance(wallet.getBalance())
                .investedValue(totalCurrentValue)
                .totalGainLoss(totalGainLoss)
                .totalGainLossPercentage(totalGainLossPercentage)
                .build();

        // Build holdings list
        List<HistoryResponse.HoldingInfo> holdingInfos = holdings.stream()
                .map(h -> HistoryResponse.HoldingInfo.builder()
                        .holdingId(h.getId())
                        .symbol(h.getStock().getSymbol())
                        .name(h.getStock().getName())
                        .quantity(h.getQuantity())
                        .averagePrice(h.getAveragePrice())
                        .currentPrice(h.getStock().getCurrentPrice())
                        .currentValue(h.getCurrentValue())
                        .gainLoss(h.getGainLoss())
                        .gainLossPercentage(h.getGainLossPercentage())
                        .purchasedAt(h.getPurchasedAt())
                        .build())
                .collect(Collectors.toList());

        // Get transactions
        List<Transaction> transactions = transactionRepository.findByPortfolioIdWithStockOrderByTransactionDateDesc(portfolioId);

        List<HistoryResponse.TransactionInfo> transactionInfos = transactions.stream()
                .map(t -> HistoryResponse.TransactionInfo.builder()
                        .transactionId(t.getId())
                        .transactionType(t.getTransactionType().toString())
                        .stockSymbol(t.getStock() != null ? t.getStock().getSymbol() : null)
                        .stockName(t.getStock() != null ? t.getStock().getName() : null)
                        .quantity(t.getQuantity())
                        .pricePerUnit(t.getPricePerUnit())
                        .totalAmount(t.getTotalAmount())
                        .fee(t.getFee())
                        .status(t.getStatus().toString())
                        .description(t.getDescription())
                        .transactionDate(t.getTransactionDate())
                        .build())
                .collect(Collectors.toList());

        return HistoryResponse.builder()
                .portfolioSummary(summary)
                .holdings(holdingInfos)
                .transactions(transactionInfos)
                .build();
    }

    private void updatePortfolioValue(Portfolio portfolio) {
        List<Holding> holdings = holdingRepository.findByPortfolioIdWithStock(portfolio.getId());
        BigDecimal totalValue = holdings.stream()
                .map(h -> {
                    h.calculateCurrentValue();
                    return h.getCurrentValue();
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        Wallet wallet = walletRepository.findByPortfolioId(portfolio.getId()).orElse(null);
        if (wallet != null) {
            totalValue = totalValue.add(wallet.getBalance());
        }

        portfolio.setTotalValue(totalValue);
        portfolioRepository.save(portfolio);
    }
}