package com.investment.investor_module.dto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvestorModuleApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvestorModuleApplication.class, args);
	}

}
