package com.investment.investor_module.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuthResponse {
    private Long investorId;
    private String email;
    private String firstName;
    private String lastName;
    private String token;
    private String message;
}