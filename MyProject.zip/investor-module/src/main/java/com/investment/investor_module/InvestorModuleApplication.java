package com.investment.investor_module;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvestorModuleApplication {

    public static void main(String[] args) {
        SpringApplication.run(InvestorModuleApplication.class, args);
        System.out.println("==============================================");
        System.out.println("Investor Module Application Started Successfully!");
        System.out.println("Server running on: http://localhost:8080");
        System.out.println("==============================================");
    }
}