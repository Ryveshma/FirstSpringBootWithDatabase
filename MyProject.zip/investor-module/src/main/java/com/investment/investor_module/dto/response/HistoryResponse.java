package com.investment.investor_module.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class HistoryResponse {
    private PortfolioSummary portfolioSummary;
    private List<HoldingInfo> holdings;
    private List<TransactionInfo> transactions;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PortfolioSummary {
        private Long portfolioId;
        private String portfolioName;
        private BigDecimal totalValue;
        private BigDecimal cashBalance;
        private BigDecimal investedValue;
        private BigDecimal totalGainLoss;
        private BigDecimal totalGainLossPercentage;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class HoldingInfo {
        private Long holdingId;
        private String symbol;
        private String name;
        private BigDecimal quantity;
        private BigDecimal averagePrice;
        private BigDecimal currentPrice;
        private BigDecimal currentValue;
        private BigDecimal gainLoss;
        private BigDecimal gainLossPercentage;
        private LocalDateTime purchasedAt;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TransactionInfo {
        private Long transactionId;
        private String transactionType;
        private String stockSymbol;
        private String stockName;
        private BigDecimal quantity;
        private BigDecimal pricePerUnit;
        private BigDecimal totalAmount;
        private BigDecimal fee;
        private String status;
        private String description;
        private LocalDateTime transactionDate;
    }
}