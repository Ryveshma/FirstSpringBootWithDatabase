package com.investment.investor_module.service;

import com.investment.investor_module.dto.request.*;
import com.investment.investor_module.dto.response.*;

public interface InvestorService {
    
    /**
     * Register a new investor with identity verification
     */
    AuthResponse register(RegisterRequest request);
    
    /**
     * Authenticate investor and return JWT token
     */
    AuthResponse login(LoginRequest request);
    
    /**
     * Logout investor (invalidate token on client side)
     */
    String logout(String token);
    
    /**
     * Get list of available stocks and ETFs
     */
    StockListResponse getAvailableStocks();
    
    /**
     * Buy stocks/ETFs
     */
    TransactionResponse buyStock(BuyRequest request, Long investorId);
    
    /**
     * Sell investments
     */
    TransactionResponse sellStock(SellRequest request, Long investorId);
    
    /**
     * Transfer funds between portfolios
     */
    TransactionResponse transferFunds(TransferRequest request, Long investorId);
    
    /**
     * Get portfolio performance and transaction history
     */
    HistoryResponse getPortfolioHistory(Long portfolioId, Long investorId);
}