package com.investment.investor_module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvestorModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
