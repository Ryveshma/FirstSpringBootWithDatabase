package BackendDevelopers.LoanEase.controllers;

import BackendDevelopers.LoanEase.model.LoanType;
import BackendDevelopers.LoanEase.service.LoanTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/loan-types")
@CrossOrigin(origins = "*")
public class LoanTypeController {
    
    @Autowired
    private LoanTypeService loanTypeService;
    
    // Get all loan types (Public access)
    @GetMapping
    public ResponseEntity<?> getAllLoanTypes() {
        try {
            List<LoanType> loanTypes = loanTypeService.getAllLoanTypes();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", loanTypes.size());
            response.put("loanTypes", loanTypes);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    // Get loan type by ID
    @GetMapping("/{id}")
    public ResponseEntity<?> getLoanTypeById(@PathVariable Long id) {
        try {
            LoanType loanType = loanTypeService.getLoanTypeById(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("loanType", loanType);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }
    
    // Add new loan type (Admin only)
    @PostMapping
    public ResponseEntity<?> addLoanType(@RequestBody LoanType loanType) {
        try {
            LoanType newLoanType = loanTypeService.addLoanType(loanType);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Loan type added successfully");
            response.put("loanType", newLoanType);
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
    
    // Update loan type (Admin only)
    @PutMapping("/{id}")
    public ResponseEntity<?> updateLoanType(@PathVariable Long id, @RequestBody LoanType loanType) {
        try {
            LoanType updatedLoanType = loanTypeService.updateLoanType(id, loanType);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Loan type updated successfully");
            response.put("loanType", updatedLoanType);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
    
    // Delete loan type (Admin only)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteLoanType(@PathVariable Long id) {
        try {
            loanTypeService.deleteLoanType(id);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Loan type deleted successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
}