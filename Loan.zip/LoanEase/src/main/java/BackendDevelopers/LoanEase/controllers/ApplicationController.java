package BackendDevelopers.LoanEase.controllers;

import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.model.LoanType;
import BackendDevelopers.LoanEase.model.User;
import BackendDevelopers.LoanEase.service.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/applications")
@CrossOrigin(origins = "*")
public class ApplicationController {
    
    @Autowired
    private ApplicationService applicationService;
    
    // Apply for a loan
    @PostMapping("/apply")
    public ResponseEntity<?> applyForLoan(
            @RequestParam("userId") Long userId,
            @RequestParam("loanTypeId") Long loanTypeId,
            @RequestParam("loanAmount") BigDecimal loanAmount,
            @RequestParam("purpose") String purpose,
            @RequestParam(value = "monthlyIncome", required = false) BigDecimal monthlyIncome,
            @RequestParam(value = "employmentType", required = false) String employmentType,
            @RequestParam(value = "document", required = false) MultipartFile document) {
        try {
            // Create loan application object
            LoanApplication application = new LoanApplication();
            
            User user = new User();
            user.setId(userId);
            application.setUser(user);
            
            LoanType loanType = new LoanType();
            loanType.setId(loanTypeId);
            application.setLoanType(loanType);
            
            application.setLoanAmount(loanAmount);
            application.setPurpose(purpose);
            application.setMonthlyIncome(monthlyIncome);
            application.setEmploymentType(employmentType);
            
            LoanApplication savedApplication = applicationService.applyForLoan(application, document);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Loan application submitted successfully");
            response.put("applicationId", savedApplication.getId());
            response.put("status", savedApplication.getStatus());
            response.put("appliedDate", savedApplication.getAppliedDate());
            
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
    
    // Get application by ID
    @GetMapping("/{applicationId}")
    public ResponseEntity<?> getApplicationById(@PathVariable Long applicationId) {
        try {
            LoanApplication application = applicationService.getApplicationById(applicationId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("application", application);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }
    
    // Get all applications by user ID
    @GetMapping("/user/{userId}")
    public ResponseEntity<?> getApplicationsByUserId(@PathVariable Long userId) {
        try {
            List<LoanApplication> applications = applicationService.getApplicationsByUserId(userId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", applications.size());
            response.put("applications", applications);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    // Get applications by status
    @GetMapping("/status/{status}")
    public ResponseEntity<?> getApplicationsByStatus(@PathVariable String status) {
        try {
            List<LoanApplication> applications = applicationService.getApplicationsByStatus(status);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("status", status);
            response.put("count", applications.size());
            response.put("applications", applications);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}