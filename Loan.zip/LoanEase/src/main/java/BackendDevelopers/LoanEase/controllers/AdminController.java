package BackendDevelopers.LoanEase.controllers;

import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
public class AdminController {
    
    @Autowired
    private AdminService adminService;
    
    // Get all applications
    @GetMapping("/applications")
    public ResponseEntity<?> getAllApplications() {
        try {
            List<LoanApplication> applications = adminService.getAllApplications();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", applications.size());
            response.put("applications", applications);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    // Get pending applications
    @GetMapping("/applications/pending")
    public ResponseEntity<?> getPendingApplications() {
        try {
            List<LoanApplication> applications = adminService.getPendingApplications();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("count", applications.size());
            response.put("applications", applications);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    // Get applications by status
    @GetMapping("/applications/status/{status}")
    public ResponseEntity<?> getApplicationsByStatus(@PathVariable String status) {
        try {
            List<LoanApplication> applications = adminService.getApplicationsByStatus(status);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("status", status);
            response.put("count", applications.size());
            response.put("applications", applications);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
    
    // Approve application
    @PutMapping("/applications/{applicationId}/approve")
    public ResponseEntity<?> approveApplication(@PathVariable Long applicationId) {
        try {
            LoanApplication application = adminService.approveApplication(applicationId);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Application approved successfully");
            response.put("applicationId", application.getId());
            response.put("status", application.getStatus());
            response.put("approvedDate", application.getApprovedDate());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
    
    // Reject application
    @PutMapping("/applications/{applicationId}/reject")
    public ResponseEntity<?> rejectApplication(
            @PathVariable Long applicationId,
            @RequestBody(required = false) Map<String, String> body) {
        try {
            String reason = (body != null && body.containsKey("reason")) 
                            ? body.get("reason") 
                            : "Application does not meet requirements";
            
            LoanApplication application = adminService.rejectApplication(applicationId, reason);
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Application rejected successfully");
            response.put("applicationId", application.getId());
            response.put("status", application.getStatus());
            response.put("rejectedDate", application.getRejectedDate());
            response.put("rejectionReason", application.getRejectionReason());
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }
    
    // Get application statistics
    @GetMapping("/statistics")
    public ResponseEntity<?> getStatistics() {
        try {
            AdminService.ApplicationStats stats = adminService.getApplicationStats();
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("statistics", stats);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("success", false);
            errorResponse.put("message", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}