package BackendDevelopers.LoanEase.model;

public enum Role { USER, ADMIN }
