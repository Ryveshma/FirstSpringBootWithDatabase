package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.LoanApplicationDao;
import BackendDevelopers.LoanEase.dao.LoanTypeDao;
import BackendDevelopers.LoanEase.dao.UserDao;
import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.model.LoanType;
import BackendDevelopers.LoanEase.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class ApplicationService {
    
    @Autowired
    private LoanApplicationDao loanApplicationDao;
    
    @Autowired
    private UserDao userDao;
    
    @Autowired
    private LoanTypeDao loanTypeDao;
    
    private final String UPLOAD_DIR = "uploads/documents/";
    
    // Apply for a new loan
    public LoanApplication applyForLoan(LoanApplication application, MultipartFile document) {
        // Validate user
        User user = userDao.findById(application.getUser().getId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Validate loan type
        LoanType loanType = loanTypeDao.findById(application.getLoanType().getId())
                .orElseThrow(() -> new RuntimeException("Loan type not found"));
        
        // Validate loan amount
        if (application.getLoanAmount().compareTo(loanType.getMinAmount()) < 0) {
            throw new RuntimeException("Loan amount cannot be less than minimum amount: " + loanType.getMinAmount());
        }
        
        if (application.getLoanAmount().compareTo(loanType.getMaxAmount()) > 0) {
            throw new RuntimeException("Loan amount cannot exceed maximum amount: " + loanType.getMaxAmount());
        }
        
        // Validate monthly income for certain loan types
        if (application.getMonthlyIncome() != null && application.getMonthlyIncome().compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Monthly income must be greater than zero");
        }
        
        application.setUser(user);
        application.setLoanType(loanType);
        application.setStatus("PENDING");
        application.setAppliedDate(LocalDateTime.now());
        
        // Save document if provided
        if (document != null && !document.isEmpty()) {
            validateDocument(document);
            String documentPath = saveDocument(document, user.getId());
            application.setDocumentPath(documentPath);
        }
        
        return loanApplicationDao.save(application);
    }
    
    // Validate document before upload
    private void validateDocument(MultipartFile file) {
        // Check file size (max 5MB)
        long maxSize = 5 * 1024 * 1024; // 5MB
        if (file.getSize() > maxSize) {
            throw new RuntimeException("File size exceeds maximum limit of 5MB");
        }
        
        // Check file type
        String contentType = file.getContentType();
        if (contentType == null || (!contentType.equals("application/pdf") 
                && !contentType.startsWith("image/"))) {
            throw new RuntimeException("Only PDF and image files are allowed");
        }
    }
    
    // Save uploaded document
    private String saveDocument(MultipartFile file, Long userId) {
        try {
            File uploadDir = new File(UPLOAD_DIR);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }
            
            // Generate unique filename
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            
            String fileName = "USER_" + userId + "_" + 
                            LocalDateTime.now().toString().replace(":", "-") + "_" + 
                            UUID.randomUUID().toString() + extension;
            
            Path filePath = Paths.get(UPLOAD_DIR + fileName);
            Files.write(filePath, file.getBytes());
            
            return filePath.toString();
        } catch (IOException e) {
            throw new RuntimeException("Failed to save document: " + e.getMessage());
        }
    }
    
    // Get all applications
    public List<LoanApplication> getAllApplications() {
        return loanApplicationDao.findAllOrderByDateDesc();
    }
    
    // Get application by ID
    public LoanApplication getApplicationById(Long id) {
        return loanApplicationDao.findById(id)
                .orElseThrow(() -> new RuntimeException("Application not found with ID: " + id));
    }
    
    // Get applications by user ID
    public List<LoanApplication> getApplicationsByUserId(Long userId) {
        // Verify user exists
        if (!userDao.existsById(userId)) {
            throw new RuntimeException("User not found with ID: " + userId);
        }
        return loanApplicationDao.findByUserId(userId);
    }
    
    // Get applications by status
    public List<LoanApplication> getApplicationsByStatus(String status) {
        // Validate status
        if (!status.matches("PENDING|APPROVED|REJECTED")) {
            throw new RuntimeException("Invalid status. Must be PENDING, APPROVED, or REJECTED");
        }
        return loanApplicationDao.findByStatus(status);
    }
    
    // Count applications by status
    public Long countApplicationsByStatus(String status) {
        return loanApplicationDao.countByStatus(status);
    }
}