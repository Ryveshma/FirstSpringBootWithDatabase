package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.LoanApplicationDao;
import BackendDevelopers.LoanEase.model.LoanApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class AdminService {
    
    @Autowired
    private LoanApplicationDao loanApplicationDao;
    
    // Get all applications for admin review
    public List<LoanApplication> getAllApplications() {
        return loanApplicationDao.findAllOrderByDateDesc();
    }
    
    // Get applications by status
    public List<LoanApplication> getApplicationsByStatus(String status) {
        return loanApplicationDao.findByStatus(status);
    }
    
    // Get pending applications
    public List<LoanApplication> getPendingApplications() {
        return loanApplicationDao.findByStatus("PENDING");
    }
    
    // Approve application
    public LoanApplication approveApplication(Long applicationId) {
        LoanApplication application = loanApplicationDao.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found with ID: " + applicationId));
        
        if (!"PENDING".equals(application.getStatus())) {
            throw new RuntimeException("Only pending applications can be approved");
        }
        
        application.setStatus("APPROVED");
        application.setApprovedDate(LocalDateTime.now());
        
        LoanApplication savedApp = loanApplicationDao.save(application);
        
        // Here you can add email notification logic
        System.out.println("Application " + applicationId + " APPROVED for user: " + 
                          application.getUser().getUsername());
        
        return savedApp;
    }
    
    // Reject application
    public LoanApplication rejectApplication(Long applicationId, String reason) {
        LoanApplication application = loanApplicationDao.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found with ID: " + applicationId));
        
        if (!"PENDING".equals(application.getStatus())) {
            throw new RuntimeException("Only pending applications can be rejected");
        }
        
        application.setStatus("REJECTED");
        application.setRejectedDate(LocalDateTime.now());
        application.setRejectionReason(reason);
        
        LoanApplication savedApp = loanApplicationDao.save(application);
        
        // Here you can add email notification logic
        System.out.println("Application " + applicationId + " REJECTED for user: " + 
                          application.getUser().getUsername() + " | Reason: " + reason);
        
        return savedApp;
    }
    
    // Get application statistics
    public ApplicationStats getApplicationStats() {
        Long totalApplications = loanApplicationDao.count();
        Long pendingCount = loanApplicationDao.countByStatus("PENDING");
        Long approvedCount = loanApplicationDao.countByStatus("APPROVED");
        Long rejectedCount = loanApplicationDao.countByStatus("REJECTED");
        
        return new ApplicationStats(totalApplications, pendingCount, approvedCount, rejectedCount);
    }
    
    // Inner class for statistics
    public static class ApplicationStats {
        private Long total;
        private Long pending;
        private Long approved;
        private Long rejected;
        
        public ApplicationStats(Long total, Long pending, Long approved, Long rejected) {
            this.total = total;
            this.pending = pending;
            this.approved = approved;
            this.rejected = rejected;
        }
        
        // Getters
        public Long getTotal() { return total; }
        public Long getPending() { return pending; }
        public Long getApproved() { return approved; }
        public Long getRejected() { return rejected; }
    }
}