package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.UserDao;
import BackendDevelopers.LoanEase.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class AuthService {
    
    @Autowired
    private UserDao userDao;
    
    // Register new user
    public User registerUser(User user) {
        // Check if username already exists
        if (userDao.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists");
        }
        
        // Check if email already exists
        if (userDao.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        // Set default role if not provided
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("USER");
        }
        
        // Save user with plain password
        return userDao.save(user);
    }
    
    // Login user - simple authentication
    public User loginUser(String username, String password) {
        Optional<User> userOpt = userDao.findByUsernameAndPassword(username, password);
        
        if (userOpt.isPresent()) {
            return userOpt.get();
        }
        
        throw new RuntimeException("Invalid username or password");
    }
    
    // Get user by ID
    public User getUserById(Long id) {
        return userDao.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + id));
    }
    
    // Get user by username
    public User getUserByUsername(String username) {
        return userDao.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found with username: " + username));
    }
    
    // Update user profile
    public User updateUser(User user) {
        if (!userDao.existsById(user.getId())) {
            throw new RuntimeException("User not found");
        }
        return userDao.save(user);
    }
    
    // Check if user exists
    public boolean userExists(String username) {
        return userDao.existsByUsername(username);
    }
}