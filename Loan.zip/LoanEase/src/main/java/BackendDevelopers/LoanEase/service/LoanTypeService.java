package BackendDevelopers.LoanEase.service;

import BackendDevelopers.LoanEase.dao.LoanTypeDao;
import BackendDevelopers.LoanEase.model.LoanType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class LoanTypeService {
    
    @Autowired
    private LoanTypeDao loanTypeDao;
    
    // Get all loan types
    public List<LoanType> getAllLoanTypes() {
        return loanTypeDao.findAll();
    }
    
    // Get loan type by ID
    public LoanType getLoanTypeById(Long id) {
        return loanTypeDao.findById(id)
                .orElseThrow(() -> new RuntimeException("Loan type not found with ID: " + id));
    }
    
    // Get loan type by name
    public LoanType getLoanTypeByName(String name) {
        return loanTypeDao.findByName(name)
                .orElseThrow(() -> new RuntimeException("Loan type not found with name: " + name));
    }
    
    // Add new loan type (Admin only)
    public LoanType addLoanType(LoanType loanType) {
        if (loanTypeDao.existsByName(loanType.getName())) {
            throw new RuntimeException("Loan type with name '" + loanType.getName() + "' already exists");
        }
        return loanTypeDao.save(loanType);
    }
    
    // Update loan type (Admin only)
    public LoanType updateLoanType(Long id, LoanType loanType) {
        LoanType existing = getLoanTypeById(id);
        
        existing.setName(loanType.getName());
        existing.setDescription(loanType.getDescription());
        existing.setInterestRate(loanType.getInterestRate());
        existing.setMaxAmount(loanType.getMaxAmount());
        existing.setMinAmount(loanType.getMinAmount());
        existing.setTenureMonths(loanType.getTenureMonths());
        
        return loanTypeDao.save(existing);
    }
    
    // Delete loan type (Admin only)
    public void deleteLoanType(Long id) {
        if (!loanTypeDao.existsById(id)) {
            throw new RuntimeException("Loan type not found with ID: " + id);
        }
        loanTypeDao.deleteById(id);
    }
}