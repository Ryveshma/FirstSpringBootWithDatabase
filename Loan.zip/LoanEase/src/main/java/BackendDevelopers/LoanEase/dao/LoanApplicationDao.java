package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.LoanApplication;
import BackendDevelopers.LoanEase.model.User;
import BackendDevelopers.LoanEase.model.LoanType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface LoanApplicationDao extends JpaRepository<LoanApplication, Long> {
    
    List<LoanApplication> findByUser(User user);
    
    List<LoanApplication> findByUserId(Long userId);
    
    List<LoanApplication> findByStatus(String status);
    
    List<LoanApplication> findByLoanType(LoanType loanType);
    
    List<LoanApplication> findByUserAndStatus(User user, String status);
    
    List<LoanApplication> findByLoanTypeAndStatus(LoanType loanType, String status);
    
    @Query("SELECT la FROM LoanApplication la ORDER BY la.appliedDate DESC")
    List<LoanApplication> findAllOrderByDateDesc();
    
    @Query("SELECT COUNT(la) FROM LoanApplication la WHERE la.status = ?1")
    Long countByStatus(String status);
}