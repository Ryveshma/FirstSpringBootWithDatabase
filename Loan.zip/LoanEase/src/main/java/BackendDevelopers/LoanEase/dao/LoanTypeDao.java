package BackendDevelopers.LoanEase.dao;

import BackendDevelopers.LoanEase.model.LoanType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface LoanTypeDao extends JpaRepository<LoanType, Long> {
    
    Optional<LoanType> findByName(String name);
    
    boolean existsByName(String name);
}