package BackendDevelopers.LoanEase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanEaseApplication {
    
    public static void main(String[] args) {
        SpringApplication.run(LoanEaseApplication.class, args);
        System.out.println("========================================");
        System.out.println("   LoanEase Application Started!");
        System.out.println("   Server running on: http://localhost:8080");
        System.out.println("========================================");
    }
}