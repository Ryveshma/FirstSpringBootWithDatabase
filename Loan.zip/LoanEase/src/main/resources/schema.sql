-- Create Database
CREATE DATABASE loanease;

-- Connect to the database
\c loanease;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'USER',
    full_name VARCHAR(100),
    phone_number VARCHAR(20)
);

-- Loan Types Table
CREATE TABLE IF NOT EXISTS loan_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    interest_rate DECIMAL(5,2) NOT NULL,
    max_amount DECIMAL(15,2) NOT NULL,
    min_amount DECIMAL(15,2),
    tenure_months INTEGER
);

-- Loan Applications Table
CREATE TABLE IF NOT EXISTS loan_applications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    loan_type_id INTEGER NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
    document_path VARCHAR(500),
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    loan_amount DECIMAL(15,2) NOT NULL,
    purpose TEXT,
    monthly_income DECIMAL(15,2),
    employment_type VARCHAR(50),
    approved_date TIMESTAMP,
    rejected_date TIMESTAMP,
    rejection_reason TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (loan_type_id) REFERENCES loan_types(id) ON DELETE CASCADE
);

-- Create Indexes for Better Performance
CREATE INDEX idx_user_username ON users(username);
CREATE INDEX idx_user_email ON users(email);
CREATE INDEX idx_loan_app_user ON loan_applications(user_id);
CREATE INDEX idx_loan_app_status ON loan_applications(status);
CREATE INDEX idx_loan_app_type ON loan_applications(loan_type_id);
CREATE INDEX idx_loan_app_date ON loan_applications(applied_date DESC);

-- ========================================
-- INSERT SAMPLE DATA - USERS (10 Users)
-- ========================================

-- Admin Users
INSERT INTO users (username, password, email, role, full_name, phone_number) VALUES
('admin', 'admin123', 'admin@loanease.com', 'ADMIN', 'System Administrator', '9999999999'),
('admin_support', 'admin456', 'support@loanease.com', 'ADMIN', 'Support Admin', '9999888877');

-- Regular Users
INSERT INTO users (username, password, email, role, full_name, phone_number) VALUES
('john_doe', 'password123', 'john@example.com', 'USER', 'John Doe', '9876543210'),
('jane_smith', 'pass456', 'jane.smith@example.com', 'USER', 'Jane Smith', '9876543211'),
('robert_kumar', 'robert123', 'robert.kumar@example.com', 'USER', 'Robert Kumar', '9876543212'),
('priya_sharma', 'priya789', 'priya.sharma@example.com', 'USER', 'Priya Sharma', '9876543213'),
('amit_patel', 'amit2024', 'amit.patel@example.com', 'USER', 'Amit Patel', '9876543214'),
('sneha_reddy', 'sneha999', 'sneha.reddy@example.com', 'USER', 'Sneha Reddy', '9876543215'),
('rajesh_verma', 'rajesh555', 'rajesh.verma@example.com', 'USER', 'Rajesh Verma', '9876543216'),
('kavya_nair', 'kavya321', 'kavya.nair@example.com', 'USER', 'Kavya Nair', '9876543217');

-- ========================================
-- INSERT SAMPLE DATA - LOAN TYPES (8 Types)
-- ========================================

INSERT INTO loan_types (name, description, interest_rate, max_amount, min_amount, tenure_months) VALUES
('Home Loan', 'Loan for purchasing or constructing a residential property', 7.50, 10000000.00, 500000.00, 240),
('Personal Loan', 'Unsecured loan for personal needs and emergencies', 12.00, 1000000.00, 50000.00, 60),
('Education Loan', 'Loan for higher education expenses in India and abroad', 9.00, 3000000.00, 100000.00, 84),
('Vehicle Loan', 'Loan for purchasing two-wheelers and four-wheelers', 10.50, 2000000.00, 100000.00, 60),
('Business Loan', 'Loan for starting or expanding business operations', 11.00, 5000000.00, 200000.00, 120),
('Gold Loan', 'Loan against gold ornaments and jewelry', 8.25, 2500000.00, 25000.00, 36),
('Property Loan', 'Loan against residential or commercial property', 9.75, 15000000.00, 1000000.00, 180),
('Medical Loan', 'Loan for medical emergencies and healthcare expenses', 11.50, 500000.00, 25000.00, 48);

-- ========================================
-- INSERT SAMPLE DATA - LOAN APPLICATIONS (15 Applications)
-- ========================================

-- Pending Applications
INSERT INTO loan_applications (user_id, loan_type_id, loan_amount, purpose, monthly_income, employment_type, status, applied_date) VALUES
(3, 1, 2500000.00, 'Purchase a 3BHK apartment in Bangalore', 80000.00, 'Salaried', 'PENDING', CURRENT_TIMESTAMP - INTERVAL '2 days'),
(4, 3, 1500000.00, 'Masters degree in USA', 60000.00, 'Salaried', 'PENDING', CURRENT_TIMESTAMP - INTERVAL '1 day'),
(5, 5, 3000000.00, 'Expand manufacturing business', 120000.00, 'Business', 'PENDING', CURRENT_TIMESTAMP - INTERVAL '3 hours'),
(6, 2, 150000.00, 'Home renovation and repairs', 50000.00, 'Self-Employed', 'PENDING', CURRENT_TIMESTAMP - INTERVAL '5 hours'),
(7, 4, 800000.00, 'Purchase Honda City car', 75000.00, 'Salaried', 'PENDING', CURRENT_TIMESTAMP - INTERVAL '1 hour');

-- Approved Applications
INSERT INTO loan_applications (user_id, loan_type_id, loan_amount, purpose, monthly_income, employment_type, status, applied_date, approved_date) VALUES
(3, 2, 200000.00, 'Medical emergency treatment', 80000.00, 'Salaried', 'APPROVED', CURRENT_TIMESTAMP - INTERVAL '10 days', CURRENT_TIMESTAMP - INTERVAL '8 days'),
(8, 6, 500000.00, 'Business working capital against gold', 90000.00, 'Business', 'APPROVED', CURRENT_TIMESTAMP - INTERVAL '15 days', CURRENT_TIMESTAMP - INTERVAL '12 days'),
(9, 1, 5000000.00, 'Purchase villa in Goa', 150000.00, 'Salaried', 'APPROVED', CURRENT_TIMESTAMP - INTERVAL '20 days', CURRENT_TIMESTAMP - INTERVAL '15 days'),
(10, 3, 2000000.00, 'MBA from IIM Bangalore', 70000.00, 'Salaried', 'APPROVED', CURRENT_TIMESTAMP - INTERVAL '25 days', CURRENT_TIMESTAMP - INTERVAL '20 days'),
(4, 8, 100000.00, 'Surgery expenses for family member', 60000.00, 'Salaried', 'APPROVED', CURRENT_TIMESTAMP - INTERVAL '30 days', CURRENT_TIMESTAMP - INTERVAL '28 days');

-- Rejected Applications
INSERT INTO loan_applications (user_id, loan_type_id, loan_amount, purpose, monthly_income, employment_type, status, applied_date, rejected_date, rejection_reason) VALUES
(3, 4, 800000.00, 'Purchase a new car', 80000.00, 'Salaried', 'REJECTED', CURRENT_TIMESTAMP - INTERVAL '12 days', CURRENT_TIMESTAMP - INTERVAL '10 days', 'Insufficient credit score'),
(5, 2, 500000.00, 'Personal expenses', 45000.00, 'Self-Employed', 'REJECTED', CURRENT_TIMESTAMP - INTERVAL '18 days', CURRENT_TIMESTAMP - INTERVAL '16 days', 'Income does not meet minimum requirement'),
(6, 1, 8000000.00, 'Purchase luxury apartment', 55000.00, 'Salaried', 'REJECTED', CURRENT_TIMESTAMP - INTERVAL '22 days', CURRENT_TIMESTAMP - INTERVAL '20 days', 'Loan amount too high compared to income'),
(7, 5, 10000000.00, 'Start new tech company', 65000.00, 'Salaried', 'REJECTED', CURRENT_TIMESTAMP - INTERVAL '28 days', CURRENT_TIMESTAMP - INTERVAL '25 days', 'Insufficient business plan documentation'),
(9, 2, 750000.00, 'Wedding expenses', 48000.00, 'Self-Employed', 'REJECTED', CURRENT_TIMESTAMP - INTERVAL '35 days', CURRENT_TIMESTAMP - INTERVAL '33 days', 'Existing loan liabilities too high');

-- ========================================
-- DISPLAY RESULTS
-- ========================================

-- Display all tables
SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name;

-- Display counts
SELECT 'Users' as table_name, COUNT(*) as record_count FROM users
UNION ALL
SELECT 'Loan Types', COUNT(*) FROM loan_types
UNION ALL
SELECT 'Loan Applications', COUNT(*) FROM loan_applications;

-- Display status-wise application counts
SELECT 
    status,
    COUNT(*) as count
FROM loan_applications
GROUP BY status
ORDER BY status;

-- Display user-wise application counts
SELECT 
    u.full_name,
    u.email,
    COUNT(la.id) as total_applications
FROM users u
LEFT JOIN loan_applications la ON u.id = la.user_id
WHERE u.role = 'USER'
GROUP BY u.id, u.full_name, u.email
ORDER BY total_applications DESC;

-- Display loan type popularity
SELECT 
    lt.name,
    COUNT(la.id) as application_count,
    lt.interest_rate
FROM loan_types lt
LEFT JOIN loan_applications la ON lt.id = la.loan_type_id
GROUP BY lt.id, lt.name, lt.interest_rate
ORDER BY application_count DESC;
