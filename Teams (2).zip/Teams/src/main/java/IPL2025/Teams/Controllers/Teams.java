package IPL2025.Teams.Controllers;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import IPL2025.Teams.model.Team;
import IPL2025.Teams.service.TeamService;

@RestController
//converts normal java class into a controller.
//controller has one or more API's
@RequestMapping("/TeamsList")
public class Teams {
	public long visitorCount = 0;
	// this is a model.
	@Autowired
	TeamService service;

	public Teams() {
		System.err.println("Teams Controller Created...");
	}

	// Link the API with the browser.
	// If the request type is GET and URL is http://localhost:9080/shopping/ ,
	// then call home function and return response to the client.
	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String home() {
		visitorCount++;
		// Preparing response and sends it to the client.
		String response = "<html><body><h1>";
		response += "Welcome to online shopping</h1><br>";
		response += "<b>You are a visitor # </b>" + visitorCount;
		response += "</body></html>";
		return response;
	}

	@GetMapping(path = "/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public ArrayList<Team> getProductsList() {
		return service.getProductsList();
	}

	@GetMapping("/search")
	public String searchTeam(@RequestParam("tId") int teamId) {
		return service.searchById(teamId);
	}

	@DeleteMapping(path="/deleteId/{tId}")
	public String deleteTeam(@PathVariable("tId") int teamId) {
		System.out.println("Got a request...");
		return service.deleteProduct(teamId);
	}
	

	@PostMapping(path = "/add", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String addProduct(@RequestBody Team p) {
		System.out.println("Got a POST request...");
		return service.addProduct(p);

	}

	@PutMapping(path = "/update", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateProduct(@RequestBody Team p) {
		System.out.println("Got a POST request...");
		return service.updateProduct(p.getTeamId(), p.getTeamName());

	}
}
