package IPL2025.Teams.dao;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import IPL2025.Teams.model.Team;

@Repository
public interface TeamsList extends CrudRepository<Team, Integer>{
/* CrudRepository<Product, Integer>
 * Product is the data that will be inserted into the database
 * or retrieved from the db.
 * Integer is the datatype of the primary key.
*/
}