package IPL2025.Teams.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Team")
public class Team{
	@Id
	private int teamId;
	@Column(name="teamName")
	private String teamName;
	public Team() {
		super();
		System.out.println("New team created...");
		// TODO Auto-generated constructor stub
	}
	public Team(int teamId, String teamName) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		System.out.println("New team created with teamId & teamName...");
	}

	public int getTeamId() {
		return teamId;
	}
	public void setTeamId(int teamId) {
		this.teamId = teamId;
		System.out.println("Stored teamID");
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
		System.out.println("Stored teamName");
	}
	@Override
	public String toString() {
		return "Team [TeamId=" + teamId + ", TeamName=" + teamName + "]" + hashCode();
	}
	
}