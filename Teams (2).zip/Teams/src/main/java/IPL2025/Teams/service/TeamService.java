package IPL2025.Teams.service;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import IPL2025.Teams.dao.TeamsList;
import IPL2025.Teams.model.Team;

@Service
public class TeamService {
	
	@Autowired
	TeamsList tlist;
	public ArrayList<Team> getProductsList(){
		System.out.println("Getting products list...");
		//When u call findAll() method in the repository, it executes a
		//SQL SELECT * from Products statement on the db.
		return (ArrayList<Team>)tlist.findAll();
	}
	public String addProduct(Team p) {
		System.out.println("In service. Adding product...");
		Team t=tlist.save(p); //Converts this to SQL INSERT statement.
		return "<b>Added or inserted the product</b>" + t;
	}
	public String deleteProduct(int teamId) {
		System.out.println("In service. Deleting product...");
		//When deleteByID() is called, it will convert this into 
		//SQL DELETE from Product WHERE productId=productId
		tlist.deleteById(teamId);
		return "<b>Deleted product with ID </b>" + teamId;
	}
	public String searchById(int teamId) {
		System.out.println("In service. Searching product...");
		//If productId is 4, this is converted to SQL
		//SELECT * from Product where productId=4
		Optional<Team> opt=tlist.findById(teamId);
		return "Located product" + opt.get().toString();
		
	}
	public String updateProduct(int teamId, String newTeamName) {
		System.out.println("In service. updating product...");
		Team d=new Team(teamId, newTeamName);
		//When save() method is called, if any product with given productId 
		//is existing, it updates the productName with newProductName.
		//Otherwise, it inserts a new record.
		return "Updated product" + tlist.save(d).toString();
	}
}